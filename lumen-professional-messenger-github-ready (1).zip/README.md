# Lumen Professional Messenger PWA

A professional messenger Progressive Web App built with Next.js, React, PostgreSQL, Drizzle ORM, and TypeScript.

## Stack

- Next.js 16
- React 19
- TypeScript
- PostgreSQL + `pg`
- Drizzle ORM
- PWA manifest + service worker
- Zod validation

## Getting started

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment variables

Copy `.env.example` to `.env.local` and replace the placeholder values with your local configuration.

```bash
cp .env.example .env.local
```

Required variables:

- `DATABASE_URL` — PostgreSQL connection string
- `AUTH_SECRET` — long random secret used by the authentication layer
- `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` — optional Google authentication credentials, if enabled

Never commit `.env.local` or real credentials to Git.

### 3. Run the development server

```bash
npm run dev
```

Open http://localhost:3000.

## Quality checks

```bash
npm run lint
npm run typecheck
npm run build
```

## GitHub

Initialize Git and create the first commit:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
```

Then create an empty repository on GitHub and connect it as `origin`:

```bash
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

Do not commit secrets, production `.env` files, database dumps, or generated build output.
