export type Privacy = {
  lastSeen: "everyone" | "friends" | "nobody";
  profilePhoto: "everyone" | "friends" | "nobody";
  onlineStatus: "everyone" | "friends" | "nobody";
  whoCanMessage: "everyone" | "friends" | "nobody";
  whoCanAddToGroups: "everyone" | "friends" | "nobody";
};

export type Me = {
  id: string;
  email: string | null;
  phone: string | null;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  bio: string;
  lastSeen: string;
  isOnline: boolean;
  theme: string;
  unlockedThemes: string[];
  createdAt: string;
  privacy: Privacy;
  stats: {
    gamesPlayed: number;
    wins: number;
    losses: number;
    draws: number;
    xp: number;
    level: number;
  };
  coins: number;
  unreadNotifications: number;
};

export type PublicUser = {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  bio?: string;
  isOnline: boolean;
  lastSeen: string | null;
  hidePhoto?: boolean;
};

export type Conversation = {
  id: string;
  type: "direct" | "group" | "channel";
  title: string | null;
  description?: string | null;
  photoUrl: string | null;
  peer: PublicUser | null;
  role: string;
  muted: boolean;
  pinned: boolean;
  memberCount?: number;
  unread: number;
  lastMessage: {
    id: string;
    content: string;
    type: string;
    senderId: string | null;
    createdAt: string;
  } | null;
  updatedAt: string;
};

export type ChatMessage = {
  id: string;
  conversationId: string;
  sender: PublicUser | null;
  senderId: string | null;
  content: string;
  type: string;
  attachment: string | null;
  fileName: string | null;
  mimeType: string | null;
  replyTo: { id: string; content: string; senderId: string | null } | null;
  forwardedFrom: string | null;
  editedAt: string | null;
  deletedAt: string | null;
  createdAt: string;
  reactions: Record<string, { count: number; mine: boolean }>;
  seenBy: number;
};

export async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers);
  const isForm = typeof FormData !== "undefined" && init?.body instanceof FormData;
  if (!isForm && init?.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  const res = await fetch(`/api/${path}`, {
    ...init,
    headers,
    credentials: "include",
  });
  const data = (await res.json().catch(() => ({}))) as { error?: string } & T;
  if (!res.ok) {
    throw new Error(data.error || "خطایی رخ داد");
  }
  return data;
}

export function initials(name: string) {
  const parts = name.trim().split(/\s+/).slice(0, 2);
  return parts.map((p) => p[0]?.toUpperCase() ?? "").join("") || "L";
}

export function colorFrom(id: string) {
  const palette = ["#8B7CFF", "#4EE1FF", "#E4C078", "#FF6B8A", "#5EEAD4", "#7C9CFF"];
  let n = 0;
  for (let i = 0; i < id.length; i++) n = (n + id.charCodeAt(i) * (i + 1)) % palette.length;
  return palette[n];
}

export function timeAgo(input: string | Date | null) {
  if (!input) return "";
  const d = new Date(input);
  const diff = Date.now() - d.getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "الان";
  if (m < 60) return `${m} دقیقه`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} ساعت`;
  const days = Math.floor(h / 24);
  if (days < 7) return `${days} روز`;
  return d.toLocaleDateString("fa-IR");
}

export function clock(input: string | Date) {
  return new Date(input).toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" });
}

export function playPing() {
  try {
    const ctx = new AudioContext();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = "sine";
    o.frequency.value = 880;
    g.gain.value = 0.04;
    o.connect(g);
    g.connect(ctx.destination);
    o.start();
    o.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.08);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.28);
    o.stop(ctx.currentTime + 0.3);
  } catch {
    /* ignore */
  }
}

export function fileToDataUrl(file: File, max = 1_200_000) {
  return new Promise<string>((resolve, reject) => {
    if (file.size > max) {
      reject(new Error("حجم فایل زیاد است (حداکثر حدود ۱ مگابایت)."));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("خواندن فایل ناموفق بود."));
    reader.readAsDataURL(file);
  });
}
