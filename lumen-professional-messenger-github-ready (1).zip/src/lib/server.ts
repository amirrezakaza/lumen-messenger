import { compare, hash } from "bcryptjs";
import { jwtVerify, SignJWT } from "jose";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { and, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  coins,
  conversationMembers,
  friendships,
  gameStats,
  privacySettings,
  sessions,
  users,
} from "@/db/schema";

const COOKIE = "lumen_token";

function getSecret() {
  const s = process.env.AUTH_SECRET;
  if (!s) throw new Error("AUTH_SECRET is required");
  return new TextEncoder().encode(s);
}

export async function hashPassword(password: string) {
  return hash(password, 10);
}

export async function verifyPassword(password: string, passwordHash: string) {
  return compare(password, passwordHash);
}

export function json<T>(data: T, status = 200) {
  return NextResponse.json(data, { status });
}

export function error(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export async function setAuthCookie(
  userId: string,
  remember: boolean,
) {
  const days = remember ? 30 : 7;
  const expiresAt = new Date(Date.now() + days * 86400000);
  const [session] = await db
    .insert(sessions)
    .values({ userId, expiresAt })
    .returning();

  const token = await new SignJWT({ sid: session.id })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(userId)
    .setExpirationTime(`${days}d`)
    .setIssuedAt()
    .sign(getSecret());

  const res = NextResponse.json({ ok: true });
  res.cookies.set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: days * 86400,
    secure: process.env.NODE_ENV === "production",
  });
  return { res, sessionId: session.id, token };
}

export async function attachAuth(
  response: NextResponse,
  userId: string,
  remember: boolean,
) {
  const days = remember ? 30 : 7;
  const expiresAt = new Date(Date.now() + days * 86400000);
  const [session] = await db
    .insert(sessions)
    .values({ userId, expiresAt })
    .returning();

  const token = await new SignJWT({ sid: session.id })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(userId)
    .setExpirationTime(`${days}d`)
    .setIssuedAt()
    .sign(getSecret());

  response.cookies.set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: days * 86400,
    secure: process.env.NODE_ENV === "production",
  });
  return response;
}

export function clearAuth(response: NextResponse) {
  response.cookies.set(COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 0,
  });
  return response;
}

export type AuthedUser = {
  id: string;
  email: string | null;
  phone: string | null;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  bio: string;
  lastSeen: Date;
  isOnline: boolean;
  isSystem: boolean;
  theme: string;
  unlockedThemes: string;
  createdAt: Date;
};

export async function getCurrentUser(): Promise<AuthedUser | null> {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, getSecret());
    const userId = payload.sub;
    const sid = payload.sid as string | undefined;
    if (!userId || !sid) return null;

    const [session] = await db
      .select()
      .from(sessions)
      .where(and(eq(sessions.id, sid), gt(sessions.expiresAt, new Date())))
      .limit(1);
    if (!session || session.userId !== userId) return null;

    const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (!user || user.isSystem) return null;
    return user;
  } catch {
    return null;
  }
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) return { user: null, err: error("نشست نامعتبر است. دوباره وارد شوید.", 401) };
  return { user, err: null };
}

const buckets = new Map<string, { n: number; t: number }>();

export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || now - b.t > windowMs) {
    buckets.set(key, { n: 1, t: now });
    return true;
  }
  if (b.n >= limit) return false;
  b.n += 1;
  return true;
}

export function clientKey(req: Request, extra: string) {
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "local";
  return `${ip}:${extra}`;
}

export async function emitEvent(event: Record<string, unknown>) {
  const payload = JSON.stringify(event);
  if (payload.length > 7000) {
    const slim = JSON.stringify({
      type: event.type,
      conversationId: event.conversationId,
      matchId: event.matchId,
      userIds: event.userIds,
      messageId: event.messageId,
    });
    await db.execute(sql`SELECT pg_notify('lumen_event', ${slim})`);
    return;
  }
  await db.execute(sql`SELECT pg_notify('lumen_event', ${payload})`);
}

export async function ensureUserExtras(userId: string) {
  await db.insert(privacySettings).values({ userId }).onConflictDoNothing();
  await db.insert(gameStats).values({ userId }).onConflictDoNothing();
  await db.insert(coins).values({ userId, balance: 100 }).onConflictDoNothing();
}

export function isFriendStatus(
  a: string,
  b: string,
  rows: { requesterId: string; addresseeId: string; status: string }[],
) {
  return rows.some(
    (f) =>
      f.status === "accepted" &&
      ((f.requesterId === a && f.addresseeId === b) ||
        (f.requesterId === b && f.addresseeId === a)),
  );
}

export async function getFriendIds(userId: string) {
  const rows = await db
    .select()
    .from(friendships)
    .where(
      and(
        eq(friendships.status, "accepted"),
        sql`(${friendships.requesterId} = ${userId} OR ${friendships.addresseeId} = ${userId})`,
      ),
    );
  return rows.map((f) => (f.requesterId === userId ? f.addresseeId : f.requesterId));
}

export async function areFriends(a: string, b: string) {
  if (a === b) return true;
  const rows = await db
    .select()
    .from(friendships)
    .where(
      and(
        eq(friendships.status, "accepted"),
        sql`((${friendships.requesterId} = ${a} AND ${friendships.addresseeId} = ${b}) OR (${friendships.requesterId} = ${b} AND ${friendships.addresseeId} = ${a}))`,
      ),
    )
    .limit(1);
  return rows.length > 0;
}

export type Visibility = "everyone" | "friends" | "nobody";

export function canSee(setting: Visibility, isSelf: boolean, friend: boolean) {
  if (isSelf) return true;
  if (setting === "everyone") return true;
  if (setting === "friends") return friend;
  return false;
}

export async function memberIds(conversationId: string) {
  const rows = await db
    .select({ userId: conversationMembers.userId })
    .from(conversationMembers)
    .where(eq(conversationMembers.conversationId, conversationId));
  return rows.map((r) => r.userId);
}

export function sanitizeText(input: unknown, max = 4000) {
  if (typeof input !== "string") return "";
  return input.replace(/\u0000/g, "").trim().slice(0, max);
}

export function validUsername(name: string) {
  return /^[a-zA-Z0-9_]{3,20}$/.test(name);
}

export function validPassword(password: string) {
  return password.length >= 8 && /[A-Za-z]/.test(password) && /\d/.test(password);
}

export function validEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function validPhone(phone: string) {
  const d = phone.replace(/[^\d+]/g, "");
  return /^\+?\d{10,15}$/.test(d);
}

export function normalizePhone(phone: string) {
  return phone.replace(/[^\d+]/g, "");
}

const ALLOWED_MIME = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "audio/webm",
  "audio/mp4",
  "audio/mpeg",
  "audio/ogg",
  "application/pdf",
  "text/plain",
]);

export function validAttachment(dataUrl: string, mime?: string | null) {
  if (!dataUrl.startsWith("data:")) return false;
  if (dataUrl.length > 1_800_000) return false;
  const m = mime || dataUrl.slice(5, dataUrl.indexOf(";"));
  if (!m) return false;
  if (ALLOWED_MIME.has(m)) return true;
  return m.startsWith("image/") || m.startsWith("audio/");
}

export function levelFromXp(xp: number) {
  return Math.max(1, Math.floor(xp / 100) + 1);
}

export async function applyGameResult(
  userId: string,
  result: "win" | "loss" | "draw",
  reason: string,
) {
  const [stats] = await db.select().from(gameStats).where(eq(gameStats.userId, userId)).limit(1);
  const xpGain = result === "win" ? 50 : result === "draw" ? 20 : 10;
  const coinGain = result === "win" ? 25 : result === "draw" ? 10 : 5;
  const gamesPlayed = (stats?.gamesPlayed ?? 0) + 1;
  const wins = (stats?.wins ?? 0) + (result === "win" ? 1 : 0);
  const losses = (stats?.losses ?? 0) + (result === "loss" ? 1 : 0);
  const draws = (stats?.draws ?? 0) + (result === "draw" ? 1 : 0);
  const xp = (stats?.xp ?? 0) + xpGain;
  const level = levelFromXp(xp);

  await db
    .insert(gameStats)
    .values({ userId, gamesPlayed, wins, losses, draws, xp, level })
    .onConflictDoUpdate({
      target: gameStats.userId,
      set: { gamesPlayed, wins, losses, draws, xp, level },
    });

  const [wallet] = await db.select().from(coins).where(eq(coins.userId, userId)).limit(1);
  const balance = (wallet?.balance ?? 100) + coinGain;
  await db
    .insert(coins)
    .values({ userId, balance })
    .onConflictDoUpdate({ target: coins.userId, set: { balance } });

  const { coinTransactions } = await import("@/db/schema");
  await db.insert(coinTransactions).values({ userId, amount: coinGain, reason });
}

export function publicUser(
  user: AuthedUser | typeof users.$inferSelect,
  opts: {
    friend: boolean;
    isSelf: boolean;
    privacy?: {
      lastSeen: Visibility;
      profilePhoto: Visibility;
      onlineStatus: Visibility;
    };
  },
) {
  const privacy = opts.privacy ?? {
    lastSeen: "everyone" as Visibility,
    profilePhoto: "everyone" as Visibility,
    onlineStatus: "everyone" as Visibility,
  };
  const showPhoto = canSee(privacy.profilePhoto, opts.isSelf, opts.friend);
  const showOnline = canSee(privacy.onlineStatus, opts.isSelf, opts.friend);
  const showLast = canSee(privacy.lastSeen, opts.isSelf, opts.friend);
  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    avatarUrl: showPhoto ? user.avatarUrl : null,
    bio: user.bio,
    isOnline: showOnline ? user.isOnline : false,
    lastSeen: showLast ? user.lastSeen : null,
    hidePhoto: !showPhoto,
  };
}
