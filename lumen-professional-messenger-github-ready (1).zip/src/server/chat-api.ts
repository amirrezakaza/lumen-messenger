import { and, desc, eq, ilike, inArray, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  conversationMembers,
  conversations,
  friendships,
  messageReactions,
  messages,
  notifications,
  privacySettings,
  users,
} from "@/db/schema";
import {
  areFriends,
  AuthedUser,
  canSee,
  clientKey,
  emitEvent,
  error,
  json,
  memberIds,
  publicUser,
  rateLimit,
  sanitizeText,
  validAttachment,
} from "@/lib/server";

async function membership(conversationId: string, userId: string) {
  const [row] = await db
    .select()
    .from(conversationMembers)
    .where(
      and(
        eq(conversationMembers.conversationId, conversationId),
        eq(conversationMembers.userId, userId),
      ),
    )
    .limit(1);
  return row ?? null;
}

function canPost(
  type: string,
  role: string,
) {
  if (type === "channel") return role === "owner" || role === "admin";
  return true;
}

function canModerate(role: string) {
  return role === "owner" || role === "admin" || role === "moderator";
}

async function mapUsers(ids: string[], me: AuthedUser) {
  if (!ids.length) return new Map<string, ReturnType<typeof publicUser>>();
  const unique = [...new Set(ids)];
  const rows = await db.select().from(users).where(inArray(users.id, unique));
  const priv = await db
    .select()
    .from(privacySettings)
    .where(inArray(privacySettings.userId, unique));
  const privMap = new Map(priv.map((p) => [p.userId, p]));
  const friendIds = new Set<string>();
  if (unique.length) {
    const fr = await db
      .select()
      .from(friendships)
      .where(
        and(
          eq(friendships.status, "accepted"),
          or(
            eq(friendships.requesterId, me.id),
            eq(friendships.addresseeId, me.id),
          ),
        ),
      );
    for (const f of fr) {
      friendIds.add(f.requesterId === me.id ? f.addresseeId : f.requesterId);
    }
  }
  const map = new Map<string, ReturnType<typeof publicUser>>();
  for (const u of rows) {
    const p = privMap.get(u.id);
    map.set(
      u.id,
      publicUser(u, {
        friend: friendIds.has(u.id),
        isSelf: u.id === me.id,
        privacy: p
          ? {
              lastSeen: p.lastSeen,
              profilePhoto: p.profilePhoto,
              onlineStatus: p.onlineStatus,
            }
          : undefined,
      }),
    );
  }
  return map;
}

export async function handleListConversations(me: AuthedUser) {
  const mine = await db
    .select()
    .from(conversationMembers)
    .where(and(eq(conversationMembers.userId, me.id), eq(conversationMembers.hidden, false)));

  if (!mine.length) return json({ conversations: [] });
  const ids = mine.map((m) => m.conversationId);
  const convs = await db.select().from(conversations).where(inArray(conversations.id, ids));
  const allMembers = await db
    .select()
    .from(conversationMembers)
    .where(inArray(conversationMembers.conversationId, ids));

  const lastByConv = new Map<string, typeof messages.$inferSelect>();
  const lastRows = await db
    .select()
    .from(messages)
    .where(inArray(messages.conversationId, ids))
    .orderBy(desc(messages.createdAt));
  for (const row of lastRows) {
    if (!lastByConv.has(row.conversationId)) lastByConv.set(row.conversationId, row);
  }

  const userIds = allMembers.map((m) => m.userId);
  const lastSenders = [...lastByConv.values()].map((m) => m.senderId).filter(Boolean) as string[];
  const umap = await mapUsers([...userIds, ...lastSenders], me);

  const unreadMap = new Map<string, number>();
  for (const mem of mine) {
    const countRows = await db
      .select({ c: sql<number>`count(*)::int` })
      .from(messages)
      .where(
        and(
          eq(messages.conversationId, mem.conversationId),
          sql`${messages.createdAt} > ${mem.lastReadAt}`,
          sql`${messages.senderId} IS DISTINCT FROM ${me.id}`,
          sql`${messages.deletedAt} IS NULL`,
          sql`${messages.type} <> 'system'`,
        ),
      );
    unreadMap.set(mem.conversationId, Number(countRows[0]?.c ?? 0));
  }

  const result = convs.map((c) => {
    const mem = mine.find((m) => m.conversationId === c.id)!;
    const members = allMembers.filter((m) => m.conversationId === c.id);
    const last = lastByConv.get(c.id);
    let title = c.title;
    let photoUrl = c.photoUrl;
    let peer = null as ReturnType<typeof publicUser> | null;
    if (c.type === "direct") {
      const other = members.find((m) => m.userId !== me.id);
      peer = other ? umap.get(other.userId) ?? null : null;
      title = peer?.displayName ?? "گفتگو";
      photoUrl = peer?.avatarUrl ?? null;
    }
    return {
      id: c.id,
      type: c.type,
      title,
      description: c.description,
      photoUrl,
      peer,
      role: mem.role,
      muted: mem.muted,
      pinned: mem.pinned,
      lastReadAt: mem.lastReadAt,
      memberCount: members.length,
      unread: unreadMap.get(c.id) ?? 0,
      lastMessage: last
        ? {
            id: last.id,
            content: last.deletedAt ? "این پیام حذف شد" : last.content,
            type: last.type,
            senderId: last.senderId,
            createdAt: last.createdAt,
          }
        : null,
      updatedAt: last?.createdAt ?? c.createdAt,
    };
  });

  result.sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    return new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  });

  return json({ conversations: result });
}

export async function handleCreateConversation(me: AuthedUser, req: Request) {
  const body = await req.json().catch(() => null);
  const type = body?.type as string;
  if (!["direct", "group", "channel"].includes(type)) return error("نوع گفتگو نامعتبر است.");

  if (type === "direct") {
    const username = sanitizeText(body?.username, 20).toLowerCase();
    const userId = sanitizeText(body?.userId, 80);
    let peer =
      (userId
        ? (await db.select().from(users).where(eq(users.id, userId)).limit(1))[0]
        : undefined) ??
      (username
        ? (await db.select().from(users).where(eq(users.username, username)).limit(1))[0]
        : undefined);
    if (!peer || peer.id === me.id) return error("کاربر پیدا نشد.");
    const [priv] = await db
      .select()
      .from(privacySettings)
      .where(eq(privacySettings.userId, peer.id))
      .limit(1);
    const friend = await areFriends(me.id, peer.id);
    if (priv && !canSee(priv.whoCanMessage, false, friend)) {
      return error("این کاربر پیام از شما را نمی‌پذیرد.", 403);
    }

    const myMems = await db
      .select()
      .from(conversationMembers)
      .where(eq(conversationMembers.userId, me.id));
    for (const mem of myMems) {
      const [c] = await db
        .select()
        .from(conversations)
        .where(eq(conversations.id, mem.conversationId))
        .limit(1);
      if (!c || c.type !== "direct") continue;
      const others = await db
        .select()
        .from(conversationMembers)
        .where(eq(conversationMembers.conversationId, c.id));
      if (others.length === 2 && others.some((o) => o.userId === peer.id)) {
        await db
          .update(conversationMembers)
          .set({ hidden: false })
          .where(
            and(
              eq(conversationMembers.conversationId, c.id),
              eq(conversationMembers.userId, me.id),
            ),
          );
        return json({ conversation: { id: c.id } });
      }
    }

    const [c] = await db
      .insert(conversations)
      .values({ type: "direct", createdBy: me.id })
      .returning();
    await db.insert(conversationMembers).values([
      { conversationId: c.id, userId: me.id, role: "member" },
      { conversationId: c.id, userId: peer.id, role: "member" },
    ]);
    return json({ conversation: { id: c.id } });
  }

  const title = sanitizeText(body?.title, 60);
  if (title.length < 2) return error("نام لازم است.");
  const description = sanitizeText(body?.description ?? "", 240);
  const photoUrl = typeof body?.photoUrl === "string" ? body.photoUrl : null;
  if (photoUrl && !validAttachment(photoUrl, null)) return error("تصویر نامعتبر است.");
  const rawIds: string[] = Array.isArray(body?.memberIds) ? body.memberIds : [];
  const memberIdSet = [...new Set(rawIds.filter((id) => id && id !== me.id))].slice(0, 80);

  if (type === "group") {
    for (const id of memberIdSet) {
      const [p] = await db.select().from(privacySettings).where(eq(privacySettings.userId, id)).limit(1);
      const friend = await areFriends(me.id, id);
      if (p && !canSee(p.whoCanAddToGroups, false, friend)) {
        return error("یکی از کاربران اجازه افزودن به گروه را نداده است.", 403);
      }
    }
  }

  const [c] = await db
    .insert(conversations)
    .values({
      type: type as "group" | "channel",
      title,
      description,
      photoUrl,
      createdBy: me.id,
    })
    .returning();

  await db.insert(conversationMembers).values({
    conversationId: c.id,
    userId: me.id,
    role: "owner",
  });

  for (const id of memberIdSet) {
    await db.insert(conversationMembers).values({
      conversationId: c.id,
      userId: id,
      role: type === "channel" ? "subscriber" : "member",
    }).onConflictDoNothing();
    await db.insert(notifications).values({
      userId: id,
      type: type === "channel" ? "channel" : "group",
      title: type === "channel" ? "عضویت در کانال" : "دعوت به گروه",
      body: `${me.displayName} شما را به «${title}» اضافه کرد`,
      data: { conversationId: c.id },
    });
  }

  await db.insert(messages).values({
    conversationId: c.id,
    senderId: me.id,
    type: "system",
    content: type === "channel" ? `کانال «${title}» ساخته شد` : `گروه «${title}» ساخته شد`,
  });

  const ids = await memberIds(c.id);
  await emitEvent({ type: "conversation", conversationId: c.id, userIds: ids });
  return json({ conversation: { id: c.id } });
}

export async function handleGetConversation(me: AuthedUser, id: string) {
  const mem = await membership(id, me.id);
  if (!mem) return error("گفتگو پیدا نشد.", 404);
  const [c] = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  if (!c) return error("گفتگو پیدا نشد.", 404);
  const members = await db
    .select()
    .from(conversationMembers)
    .where(eq(conversationMembers.conversationId, id));
  const umap = await mapUsers(members.map((m) => m.userId), me);
  let title = c.title;
  let photoUrl = c.photoUrl;
  let peer = null as ReturnType<typeof publicUser> | null;
  if (c.type === "direct") {
    const other = members.find((m) => m.userId !== me.id);
    peer = other ? umap.get(other.userId) ?? null : null;
    title = peer?.displayName ?? "گفتگو";
    photoUrl = peer?.avatarUrl ?? null;
  }
  return json({
    conversation: {
      id: c.id,
      type: c.type,
      title,
      description: c.description,
      photoUrl,
      peer,
      role: mem.role,
      muted: mem.muted,
      pinned: mem.pinned,
      createdAt: c.createdAt,
      members: members.map((m) => ({
        ...umap.get(m.userId),
        role: m.role,
        lastReadAt: m.lastReadAt,
        userId: m.userId,
      })),
    },
  });
}

export async function handlePatchConversation(me: AuthedUser, id: string, req: Request) {
  const mem = await membership(id, me.id);
  if (!mem) return error("دسترسی ندارید.", 403);
  const [c] = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  if (!c) return error("گفتگو پیدا نشد.", 404);
  const body = await req.json().catch(() => null);
  if (!body) return error("داده نامعتبر است.");

  const memPatch: Partial<typeof conversationMembers.$inferInsert> = {};
  if (typeof body.muted === "boolean") memPatch.muted = body.muted;
  if (typeof body.pinned === "boolean") memPatch.pinned = body.pinned;
  if (typeof body.hidden === "boolean") memPatch.hidden = body.hidden;
  if (Object.keys(memPatch).length) {
    await db
      .update(conversationMembers)
      .set(memPatch)
      .where(eq(conversationMembers.id, mem.id));
  }

  const convPatch: Partial<typeof conversations.$inferInsert> = {};
  if (c.type !== "direct" && canModerate(mem.role)) {
    if (typeof body.title === "string") {
      const title = sanitizeText(body.title, 60);
      if (title.length < 2) return error("نام خیلی کوتاه است.");
      convPatch.title = title;
    }
    if (typeof body.description === "string") convPatch.description = sanitizeText(body.description, 240);
    if (body.photoUrl === null) convPatch.photoUrl = null;
    if (typeof body.photoUrl === "string") {
      if (!validAttachment(body.photoUrl, null)) return error("تصویر نامعتبر است.");
      convPatch.photoUrl = body.photoUrl;
    }
    if (Object.keys(convPatch).length) {
      await db.update(conversations).set(convPatch).where(eq(conversations.id, id));
    }
  }
  return json({ ok: true });
}

export async function handleLeaveConversation(me: AuthedUser, id: string) {
  const mem = await membership(id, me.id);
  if (!mem) return error("دسترسی ندارید.", 403);
  const [c] = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  if (!c) return error("گفتگو پیدا نشد.", 404);

  if (c.type === "direct") {
    await db
      .update(conversationMembers)
      .set({ hidden: true })
      .where(eq(conversationMembers.id, mem.id));
    return json({ ok: true });
  }

  if (mem.role === "owner") {
    const others = await db
      .select()
      .from(conversationMembers)
      .where(eq(conversationMembers.conversationId, id));
    const next =
      others.find((o) => o.userId !== me.id && o.role === "admin") ??
      others.find((o) => o.userId !== me.id);
    if (next) {
      await db
        .update(conversationMembers)
        .set({ role: "owner" })
        .where(eq(conversationMembers.id, next.id));
    } else {
      await db.delete(conversations).where(eq(conversations.id, id));
      return json({ ok: true, deleted: true });
    }
  }

  await db.delete(conversationMembers).where(eq(conversationMembers.id, mem.id));
  await db.insert(messages).values({
    conversationId: id,
    senderId: me.id,
    type: "system",
    content: `${me.displayName} گروه را ترک کرد`,
  });
  const ids = await memberIds(id);
  await emitEvent({ type: "conversation", conversationId: id, userIds: ids });
  return json({ ok: true });
}

export async function handleMembers(me: AuthedUser, id: string, req: Request, method: string, extra?: string) {
  const mem = await membership(id, me.id);
  if (!mem) return error("دسترسی ندارید.", 403);
  const [c] = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  if (!c || c.type === "direct") return error("این عمل برای این گفتگو ممکن نیست.");

  if (method === "POST") {
    if (!canModerate(mem.role)) return error("فقط مدیران می‌توانند عضو اضافه کنند.", 403);
    const body = await req.json().catch(() => null);
    const username = sanitizeText(body?.username, 20).toLowerCase();
    const userId = sanitizeText(body?.userId, 80);
    const [peer] = userId
      ? await db.select().from(users).where(eq(users.id, userId)).limit(1)
      : await db.select().from(users).where(eq(users.username, username)).limit(1);
    if (!peer) return error("کاربر پیدا نشد.");
    if (c.type === "group") {
      const [p] = await db.select().from(privacySettings).where(eq(privacySettings.userId, peer.id)).limit(1);
      const friend = await areFriends(me.id, peer.id);
      if (p && !canSee(p.whoCanAddToGroups, false, friend)) {
        return error("این کاربر اجازه افزودن به گروه را نداده.", 403);
      }
    }
    await db
      .insert(conversationMembers)
      .values({
        conversationId: id,
        userId: peer.id,
        role: c.type === "channel" ? "subscriber" : "member",
      })
      .onConflictDoNothing();
    await db.insert(messages).values({
      conversationId: id,
      senderId: me.id,
      type: "system",
      content: `${peer.displayName} اضافه شد`,
    });
    const ids = await memberIds(id);
    await emitEvent({ type: "conversation", conversationId: id, userIds: ids });
    return json({ ok: true });
  }

  if (method === "PATCH") {
    if (mem.role !== "owner" && mem.role !== "admin") return error("اجازه تغییر نقش ندارید.", 403);
    const body = await req.json().catch(() => null);
    const targetId = sanitizeText(body?.userId, 80);
    const role = sanitizeText(body?.role, 20);
    if (!["admin", "moderator", "member", "subscriber"].includes(role)) return error("نقش نامعتبر است.");
    const target = await membership(id, targetId);
    if (!target) return error("عضو پیدا نشد.");
    if (target.role === "owner") return error("نقش مالک قابل تغییر نیست.");
    if (mem.role === "admin" && target.role === "admin") return error("اجازه کافی نیست.", 403);
    await db.update(conversationMembers).set({ role: role as typeof target.role }).where(eq(conversationMembers.id, target.id));
    return json({ ok: true });
  }

  if (method === "DELETE") {
    const targetId = extra || "";
    const target = await membership(id, targetId);
    if (!target) return error("عضو پیدا نشد.");
    if (target.userId === me.id) return error("برای خروج از گزینه ترک استفاده کنید.");
    const myRole = String(mem.role);
    const theirRole = String(target.role);
    if (!["owner", "admin", "moderator"].includes(myRole)) return error("اجازه ندارید.", 403);
    if (theirRole === "owner") return error("مالک را نمی‌توان حذف کرد.");
    if (myRole === "admin" && (theirRole === "admin" || theirRole === "owner")) {
      return error("اجازه کافی نیست.", 403);
    }
    await db.delete(conversationMembers).where(eq(conversationMembers.id, target.id));
    await db.insert(messages).values({
      conversationId: id,
      senderId: me.id,
      type: "system",
      content: "یک عضو حذف شد",
    });
    return json({ ok: true });
  }

  return error("روش نامعتبر", 405);
}

export async function handleJoinChannel(me: AuthedUser, id: string) {
  const [c] = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  if (!c || c.type !== "channel") return error("کانال پیدا نشد.", 404);
  await db
    .insert(conversationMembers)
    .values({ conversationId: id, userId: me.id, role: "subscriber" })
    .onConflictDoNothing();
  return json({ ok: true, conversation: { id } });
}

export async function handleMessages(me: AuthedUser, id: string, req: Request) {
  const mem = await membership(id, me.id);
  if (!mem) return error("دسترسی ندارید.", 403);
  const url = new URL(req.url);
  const before = url.searchParams.get("before");
  const limit = Math.min(80, Math.max(20, Number(url.searchParams.get("limit") ?? 50)));

  let rows;
  if (before) {
    const [ref] = await db.select().from(messages).where(eq(messages.id, before)).limit(1);
    if (ref) {
      rows = await db
        .select()
        .from(messages)
        .where(and(eq(messages.conversationId, id), sql`${messages.createdAt} < ${ref.createdAt}`))
        .orderBy(desc(messages.createdAt))
        .limit(limit);
    } else {
      rows = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, id))
        .orderBy(desc(messages.createdAt))
        .limit(limit);
    }
  } else {
    rows = await db
      .select()
      .from(messages)
      .where(eq(messages.conversationId, id))
      .orderBy(desc(messages.createdAt))
      .limit(limit);
  }

  const chronological = rows.slice().reverse();
  const senderIds = chronological.map((m) => m.senderId).filter(Boolean) as string[];
  const umap = await mapUsers(senderIds, me);
  const msgIds = chronological.map((m) => m.id);
  const reacts = msgIds.length
    ? await db.select().from(messageReactions).where(inArray(messageReactions.messageId, msgIds))
    : [];
  const replyIds = chronological.map((m) => m.replyToId).filter(Boolean) as string[];
  const replies = replyIds.length
    ? await db.select().from(messages).where(inArray(messages.id, replyIds))
    : [];
  const replyMap = new Map(replies.map((r) => [r.id, r]));

  const members = await db
    .select()
    .from(conversationMembers)
    .where(eq(conversationMembers.conversationId, id));

  const payload = chronological.map((m) => {
    const seenBy = members.filter(
      (memRow) =>
        memRow.userId !== m.senderId &&
        m.createdAt &&
        memRow.lastReadAt >= m.createdAt,
    ).length;
    return {
      id: m.id,
      conversationId: m.conversationId,
      sender: m.senderId ? umap.get(m.senderId) ?? null : null,
      senderId: m.senderId,
      content: m.deletedAt ? "این پیام حذف شد" : m.content,
      type: m.deletedAt ? "system" : m.type,
      attachment: m.deletedAt ? null : m.attachment,
      fileName: m.deletedAt ? null : m.fileName,
      mimeType: m.deletedAt ? null : m.mimeType,
      replyTo: m.replyToId
        ? {
            id: m.replyToId,
            content: replyMap.get(m.replyToId)?.content?.slice(0, 80) ?? "",
            senderId: replyMap.get(m.replyToId)?.senderId ?? null,
          }
        : null,
      forwardedFrom: m.forwardedFrom,
      editedAt: m.editedAt,
      deletedAt: m.deletedAt,
      createdAt: m.createdAt,
      reactions: reacts
        .filter((r) => r.messageId === m.id)
        .reduce<Record<string, { count: number; mine: boolean }>>((acc, r) => {
          acc[r.emoji] = acc[r.emoji] ?? { count: 0, mine: false };
          acc[r.emoji].count += 1;
          if (r.userId === me.id) acc[r.emoji].mine = true;
          return acc;
        }, {}),
      seenBy,
    };
  });

  return json({ messages: payload, hasMore: rows.length === limit });
}

export async function handleSendMessage(me: AuthedUser, id: string, req: Request) {
  if (!rateLimit(clientKey(req, `msg:${me.id}`), 40, 20_000)) {
    return error("پیام‌ها خیلی سریع ارسال شدند.", 429);
  }
  const mem = await membership(id, me.id);
  if (!mem) return error("دسترسی ندارید.", 403);
  const [c] = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  if (!c) return error("گفتگو پیدا نشد.", 404);
  if (!canPost(c.type, mem.role)) return error("فقط مدیران کانال می‌توانند پست بگذارند.", 403);

  const body = await req.json().catch(() => null);
  const type = (body?.type as string) || "text";
  if (!["text", "image", "file", "voice"].includes(type)) return error("نوع پیام نامعتبر است.");
  const content = sanitizeText(body?.content ?? "", 4000);
  const attachment = typeof body?.attachment === "string" ? body.attachment : null;
  const fileName = sanitizeText(body?.fileName ?? "", 120) || null;
  const mimeType = sanitizeText(body?.mimeType ?? "", 80) || null;
  const replyToId = sanitizeText(body?.replyToId ?? "", 80) || null;
  const forwardedFrom = sanitizeText(body?.forwardedFrom ?? "", 80) || null;

  if (type === "text" && !content) return error("پیام خالی است.");
  if (type !== "text") {
    if (!attachment || !validAttachment(attachment, mimeType)) {
      return error("فایل نامعتبر یا بزرگ‌تر از حد مجاز است.");
    }
  }

  const [msg] = await db
    .insert(messages)
    .values({
      conversationId: id,
      senderId: me.id,
      content,
      type: type as "text" | "image" | "file" | "voice",
      attachment,
      fileName,
      mimeType,
      replyToId,
      forwardedFrom,
    })
    .returning();

  await db
    .update(conversationMembers)
    .set({ lastReadAt: new Date(), hidden: false })
    .where(
      and(eq(conversationMembers.conversationId, id), eq(conversationMembers.userId, me.id)),
    );

  const ids = await memberIds(id);
  for (const uid of ids) {
    if (uid === me.id) continue;
    const [targetMem] = await db
      .select()
      .from(conversationMembers)
      .where(and(eq(conversationMembers.conversationId, id), eq(conversationMembers.userId, uid)))
      .limit(1);
    if (targetMem?.muted) continue;
    await db.insert(notifications).values({
      userId: uid,
      type: "message",
      title: c.type === "channel" ? c.title ?? "کانال" : me.displayName,
      body: type === "text" ? content.slice(0, 80) : type === "image" ? "تصویر" : type === "voice" ? "پیام صوتی" : "فایل",
      data: { conversationId: id, messageId: msg.id },
    });
  }

  await emitEvent({
    type: "message",
    conversationId: id,
    messageId: msg.id,
    senderId: me.id,
    preview: type === "text" ? content.slice(0, 80) : type,
    userIds: ids,
  });

  return json({ message: { id: msg.id, createdAt: msg.createdAt } });
}

export async function handleRead(me: AuthedUser, id: string) {
  const mem = await membership(id, me.id);
  if (!mem) return error("دسترسی ندارید.", 403);
  await db
    .update(conversationMembers)
    .set({ lastReadAt: new Date() })
    .where(eq(conversationMembers.id, mem.id));
  const ids = await memberIds(id);
  await emitEvent({ type: "read", conversationId: id, userId: me.id, userIds: ids });
  return json({ ok: true });
}

export async function handlePatchMessage(me: AuthedUser, id: string, req: Request) {
  const [msg] = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
  if (!msg) return error("پیام پیدا نشد.", 404);
  if (msg.senderId !== me.id) return error("فقط فرستنده می‌تواند ویرایش کند.", 403);
  if (msg.type !== "text" || msg.deletedAt) return error("این پیام قابل ویرایش نیست.");
  const body = await req.json().catch(() => null);
  const content = sanitizeText(body?.content ?? "", 4000);
  if (!content) return error("متن خالی است.");
  await db
    .update(messages)
    .set({ content, editedAt: new Date() })
    .where(eq(messages.id, id));
  const ids = await memberIds(msg.conversationId);
  await emitEvent({
    type: "message",
    conversationId: msg.conversationId,
    messageId: id,
    userIds: ids,
  });
  return json({ ok: true });
}

export async function handleDeleteMessage(me: AuthedUser, id: string) {
  const [msg] = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
  if (!msg) return error("پیام پیدا نشد.", 404);
  const mem = await membership(msg.conversationId, me.id);
  if (!mem) return error("دسترسی ندارید.", 403);
  if (msg.senderId !== me.id && !canModerate(mem.role)) {
    return error("اجازه حذف این پیام را ندارید.", 403);
  }
  await db.update(messages).set({ deletedAt: new Date(), attachment: null }).where(eq(messages.id, id));
  const ids = await memberIds(msg.conversationId);
  await emitEvent({
    type: "message",
    conversationId: msg.conversationId,
    messageId: id,
    userIds: ids,
  });
  return json({ ok: true });
}

export async function handleReact(me: AuthedUser, id: string, req: Request) {
  const [msg] = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
  if (!msg) return error("پیام پیدا نشد.", 404);
  const mem = await membership(msg.conversationId, me.id);
  if (!mem) return error("دسترسی ندارید.", 403);
  const body = await req.json().catch(() => null);
  const emoji = sanitizeText(body?.emoji ?? "", 8);
  if (!emoji) return error("ایموجی لازم است.");
  const existing = await db
    .select()
    .from(messageReactions)
    .where(
      and(
        eq(messageReactions.messageId, id),
        eq(messageReactions.userId, me.id),
        eq(messageReactions.emoji, emoji),
      ),
    )
    .limit(1);
  if (existing.length) {
    await db.delete(messageReactions).where(eq(messageReactions.id, existing[0].id));
  } else {
    await db.insert(messageReactions).values({ messageId: id, userId: me.id, emoji });
  }
  const ids = await memberIds(msg.conversationId);
  await emitEvent({
    type: "message",
    conversationId: msg.conversationId,
    messageId: id,
    userIds: ids,
  });
  return json({ ok: true });
}

export async function handleForward(me: AuthedUser, id: string, req: Request) {
  const [msg] = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
  if (!msg || msg.deletedAt) return error("پیام پیدا نشد.", 404);
  const mem = await membership(msg.conversationId, me.id);
  if (!mem) return error("دسترسی ندارید.", 403);
  const body = await req.json().catch(() => null);
  const targetId = sanitizeText(body?.conversationId, 80);
  const targetMem = await membership(targetId, me.id);
  if (!targetMem) return error("گفتگوی مقصد معتبر نیست.", 403);
  const [c] = await db.select().from(conversations).where(eq(conversations.id, targetId)).limit(1);
  if (!c) return error("گفتگوی مقصد پیدا نشد.");
  if (!canPost(c.type, targetMem.role)) return error("اجازه ارسال در مقصد را ندارید.", 403);
  const senderName = me.displayName;
  await db.insert(messages).values({
    conversationId: targetId,
    senderId: me.id,
    content: msg.content,
    type: msg.type,
    attachment: msg.attachment,
    fileName: msg.fileName,
    mimeType: msg.mimeType,
    forwardedFrom: senderName,
  });
  const ids = await memberIds(targetId);
  await emitEvent({ type: "message", conversationId: targetId, userIds: ids });
  return json({ ok: true });
}

export async function handleSearch(me: AuthedUser, req: Request) {
  const q = sanitizeText(new URL(req.url).searchParams.get("q") ?? "", 80).toLowerCase();
  if (q.length < 1) return json({ users: [], conversations: [], messages: [] });

  const foundUsers = await db
    .select()
    .from(users)
    .where(
      and(
        sql`${users.isSystem} = false`,
        or(
          ilike(users.username, `%${q}%`),
          ilike(users.displayName, `%${q}%`),
          ilike(users.email, `%${q}%`),
        ),
      ),
    )
    .limit(12);

  const umap = await mapUsers(foundUsers.map((u) => u.id), me);

  const mine = await db
    .select()
    .from(conversationMembers)
    .where(eq(conversationMembers.userId, me.id));
  const convIds = mine.map((m) => m.conversationId);
  const convs = convIds.length
    ? await db
        .select()
        .from(conversations)
        .where(
          and(
            inArray(conversations.id, convIds),
            or(ilike(conversations.title, `%${q}%`), ilike(conversations.description, `%${q}%`)),
          ),
        )
        .limit(12)
    : [];

  const publicChannels = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.type, "channel"), ilike(conversations.title, `%${q}%`)))
    .limit(8);

  const msgRows = convIds.length
    ? await db
        .select()
        .from(messages)
        .where(
          and(
            inArray(messages.conversationId, convIds),
            sql`${messages.deletedAt} IS NULL`,
            ilike(messages.content, `%${q}%`),
          ),
        )
        .orderBy(desc(messages.createdAt))
        .limit(20)
    : [];

  return json({
    users: foundUsers
      .filter((u) => u.id !== me.id)
      .map((u) => umap.get(u.id)),
    conversations: [...convs, ...publicChannels.filter((c) => !convs.some((x) => x.id === c.id))].map((c) => ({
      id: c.id,
      type: c.type,
      title: c.title,
      description: c.description,
      photoUrl: c.photoUrl,
    })),
    messages: msgRows.map((m) => ({
      id: m.id,
      conversationId: m.conversationId,
      content: m.content.slice(0, 140),
      createdAt: m.createdAt,
    })),
  });
}
