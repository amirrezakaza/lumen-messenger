import { NextResponse } from "next/server";
import { and, eq, gt, or } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { passwordResets, privacySettings, sessions, users } from "@/db/schema";
import { subscribeOfficialChannel } from "@/db/seed";
import {
  areFriends,
  attachAuth,
  AuthedUser,
  clearAuth,
  clientKey,
  emitEvent,
  ensureUserExtras,
  error,
  hashPassword,
  json,
  publicUser,
  rateLimit,
  sanitizeText,
  validAttachment,
  validEmail,
  validPassword,
  validPhone,
  validUsername,
  verifyPassword,
  Visibility,
} from "@/lib/server";
import { coins, coinTransactions, gameStats, notifications } from "@/db/schema";

const registerSchema = z.object({
  displayName: z.string().min(2).max(40),
  username: z.string().min(3).max(20),
  email: z.string().optional().nullable(),
  phone: z.string().optional().nullable(),
  password: z.string().min(8).max(100),
  avatarUrl: z.string().optional().nullable(),
  remember: z.boolean().optional(),
});

const loginSchema = z.object({
  identifier: z.string().min(3).max(120),
  password: z.string().min(1).max(100),
  remember: z.boolean().optional(),
});

function zodError(err: z.ZodError) {
  return err.issues[0]?.message ?? "داده نامعتبر است";
}

export async function handleRegister(req: Request) {
  if (!rateLimit(clientKey(req, "register"), 6, 15 * 60_000)) {
    return error("تعداد تلاش‌ها زیاد است. کمی بعد دوباره امتحان کنید.", 429);
  }
  const body = await req.json().catch(() => null);
  const parsed = registerSchema.safeParse(body);
  if (!parsed.success) return error("لطفاً همه فیلدها را درست پر کنید.");

  const displayName = sanitizeText(parsed.data.displayName, 40);
  const username = sanitizeText(parsed.data.username, 20).toLowerCase();
  const password = parsed.data.password;
  const email = parsed.data.email ? sanitizeText(parsed.data.email, 120).toLowerCase() : "";
  const phone = parsed.data.phone ? parsed.data.phone.replace(/[^\d+]/g, "") : "";
  const avatarUrl = parsed.data.avatarUrl ?? null;

  if (!validUsername(username)) {
    return error("نام کاربری فقط حروف انگلیسی، عدد و _ باشد (۳ تا ۲۰ کاراکتر).");
  }
  if (!validPassword(password)) {
    return error("رمز عبور حداقل ۸ کاراکتر و شامل حرف و عدد باشد.");
  }
  if (!email && !phone) return error("ایمیل یا شماره موبایل لازم است.");
  if (email && !validEmail(email)) return error("ایمیل معتبر نیست.");
  if (phone && !validPhone(phone)) return error("شماره موبایل معتبر نیست.");
  if (avatarUrl && !validAttachment(avatarUrl, null)) return error("تصویر پروفایل نامعتبر است.");

  const [takenUser] = await db.select().from(users).where(eq(users.username, username)).limit(1);
  if (takenUser) return error("این نام کاربری قبلاً گرفته شده.");

  if (email) {
    const [takenEmail] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (takenEmail) return error("این ایمیل قبلاً ثبت شده.");
  }
  if (phone) {
    const [takenPhone] = await db.select().from(users).where(eq(users.phone, phone)).limit(1);
    if (takenPhone) return error("این شماره قبلاً ثبت شده.");
  }

  const passwordHash = await hashPassword(password);
  const [user] = await db
    .insert(users)
    .values({
      displayName,
      username,
      email: email || null,
      phone: phone || null,
      passwordHash,
      avatarUrl,
    })
    .returning();

  await ensureUserExtras(user.id);
  await subscribeOfficialChannel(user.id);
  await db.insert(notifications).values({
    userId: user.id,
    type: "welcome",
    title: "به لومن خوش آمدید",
    body: "پروفایل‌تان ساخته شد. یک گفتگو شروع کنید یا وارد بازی‌ها شوید.",
    data: {},
  });

  const payload = await serializeMe(user);
  const res = NextResponse.json({ user: payload });
  return attachAuth(res, user.id, Boolean(parsed.data.remember));
}

export async function handleLogin(req: Request) {
  if (!rateLimit(clientKey(req, "login"), 8, 10 * 60_000)) {
    return error("تلاش‌های ورود زیاد بود. چند دقیقه صبر کنید.", 429);
  }
  const body = await req.json().catch(() => null);
  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) return error("شناسه و رمز عبور را وارد کنید.");

  const identifier = sanitizeText(parsed.data.identifier, 120).toLowerCase();
  const password = parsed.data.password;

  const [user] = await db
    .select()
    .from(users)
    .where(
      or(
        eq(users.username, identifier),
        eq(users.email, identifier),
        eq(users.phone, identifier),
        eq(users.phone, parsed.data.identifier.replace(/[^\d+]/g, "")),
      ),
    )
    .limit(1);

  if (!user || user.isSystem) return error("نام کاربری یا رمز عبور نادرست است.", 401);
  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) return error("نام کاربری یا رمز عبور نادرست است.", 401);

  await db
    .update(users)
    .set({ isOnline: true, lastSeen: new Date() })
    .where(eq(users.id, user.id));
  await emitEvent({ type: "presence", userId: user.id, isOnline: true });

  const payload = await serializeMe({ ...user, isOnline: true });
  const res = NextResponse.json({ user: payload });
  return attachAuth(res, user.id, Boolean(parsed.data.remember));
}

export async function handleLogout(user: AuthedUser) {
  await db.delete(sessions).where(eq(sessions.userId, user.id));
  await db
    .update(users)
    .set({ isOnline: false, lastSeen: new Date() })
    .where(eq(users.id, user.id));
  await emitEvent({ type: "presence", userId: user.id, isOnline: false });
  return clearAuth(json({ ok: true }));
}

export async function handleForgot(req: Request) {
  if (!rateLimit(clientKey(req, "forgot"), 5, 15 * 60_000)) {
    return error("درخواست‌ها زیاد است.", 429);
  }
  const body = await req.json().catch(() => null);
  const email = sanitizeText(body?.email, 120).toLowerCase();
  if (!validEmail(email)) return error("ایمیل معتبر نیست.");

  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  // Always succeed to avoid account enumeration
  if (!user || user.isSystem) {
    return json({ ok: true, message: "اگر حسابی با این ایمیل باشد، کد بازیابی صادر شد." });
  }
  const code = String(Math.floor(100000 + Math.random() * 900000));
  const codeHash = await hashPassword(code);
  await db.insert(passwordResets).values({
    userId: user.id,
    codeHash,
    expiresAt: new Date(Date.now() + 15 * 60_000),
  });
  return json({
    ok: true,
    message: "کد بازیابی صادر شد.",
    demoCode: code,
    demoHint: "سرویس ایمیل پیکربندی نشده؛ کد فقط برای نمایش در محیط فعلی برگردانده شد.",
  });
}

export async function handleReset(req: Request) {
  if (!rateLimit(clientKey(req, "reset"), 8, 15 * 60_000)) {
    return error("درخواست‌ها زیاد است.", 429);
  }
  const body = await req.json().catch(() => null);
  const email = sanitizeText(body?.email, 120).toLowerCase();
  const code = sanitizeText(body?.code, 10);
  const password = String(body?.password ?? "");
  if (!validEmail(email) || !code) return error("ایمیل و کد بازیابی لازم است.");
  if (!validPassword(password)) {
    return error("رمز عبور حداقل ۸ کاراکتر و شامل حرف و عدد باشد.");
  }
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user) return error("کد بازیابی نامعتبر است.");
  const rows = await db
    .select()
    .from(passwordResets)
    .where(
      and(
        eq(passwordResets.userId, user.id),
        eq(passwordResets.used, false),
        gt(passwordResets.expiresAt, new Date()),
      ),
    );
  let matched = false;
  for (const row of rows) {
    if (await verifyPassword(code, row.codeHash)) {
      await db.update(passwordResets).set({ used: true }).where(eq(passwordResets.id, row.id));
      matched = true;
      break;
    }
  }
  if (!matched) return error("کد بازیابی نامعتبر یا منقضی است.");
  const passwordHash = await hashPassword(password);
  await db.update(users).set({ passwordHash }).where(eq(users.id, user.id));
  await db.delete(sessions).where(eq(sessions.userId, user.id));
  return json({ ok: true });
}

export async function serializeMe(user: AuthedUser | typeof users.$inferSelect) {
  await ensureUserExtras(user.id);
  const [privacy] = await db
    .select()
    .from(privacySettings)
    .where(eq(privacySettings.userId, user.id))
    .limit(1);
  const [stats] = await db.select().from(gameStats).where(eq(gameStats.userId, user.id)).limit(1);
  const [wallet] = await db.select().from(coins).where(eq(coins.userId, user.id)).limit(1);
  const unreadNotifs = await db
    .select()
    .from(notifications)
    .where(and(eq(notifications.userId, user.id), eq(notifications.read, false)));

  return {
    id: user.id,
    email: user.email,
    phone: user.phone,
    username: user.username,
    displayName: user.displayName,
    avatarUrl: user.avatarUrl,
    bio: user.bio,
    lastSeen: user.lastSeen,
    isOnline: user.isOnline,
    theme: user.theme,
    unlockedThemes: user.unlockedThemes.split(",").filter(Boolean),
    createdAt: user.createdAt,
    privacy: privacy ?? {
      lastSeen: "everyone",
      profilePhoto: "everyone",
      onlineStatus: "everyone",
      whoCanMessage: "everyone",
      whoCanAddToGroups: "everyone",
    },
    stats: stats ?? { gamesPlayed: 0, wins: 0, losses: 0, draws: 0, xp: 0, level: 1 },
    coins: wallet?.balance ?? 100,
    unreadNotifications: unreadNotifs.length,
  };
}

export async function handleUpdateMe(user: AuthedUser, req: Request) {
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") return error("داده نامعتبر است.");

  const patch: Partial<typeof users.$inferInsert> = {};
  if (typeof body.displayName === "string") {
    const n = sanitizeText(body.displayName, 40);
    if (n.length < 2) return error("نام خیلی کوتاه است.");
    patch.displayName = n;
  }
  if (typeof body.bio === "string") patch.bio = sanitizeText(body.bio, 180);
  if (typeof body.username === "string") {
    const username = sanitizeText(body.username, 20).toLowerCase();
    if (!validUsername(username)) return error("نام کاربری نامعتبر است.");
    const [taken] = await db.select().from(users).where(eq(users.username, username)).limit(1);
    if (taken && taken.id !== user.id) return error("این نام کاربری قبلاً گرفته شده.");
    patch.username = username;
  }
  if (body.avatarUrl === null) patch.avatarUrl = null;
  if (typeof body.avatarUrl === "string") {
    if (!validAttachment(body.avatarUrl, null)) return error("تصویر نامعتبر یا خیلی بزرگ است.");
    patch.avatarUrl = body.avatarUrl;
  }
  if (typeof body.theme === "string") {
    const unlocked = new Set(user.unlockedThemes.split(",").filter(Boolean));
    if (!unlocked.has(body.theme)) return error("این تم هنوز باز نشده.");
    patch.theme = body.theme;
  }
  if (Object.keys(patch).length) {
    await db.update(users).set(patch).where(eq(users.id, user.id));
  }
  if (body.privacy && typeof body.privacy === "object") {
    const vis = new Set(["everyone", "friends", "nobody"]);
    const p = body.privacy as Record<string, string>;
    const next: Record<string, Visibility> = {};
    for (const key of [
      "lastSeen",
      "profilePhoto",
      "onlineStatus",
      "whoCanMessage",
      "whoCanAddToGroups",
    ]) {
      if (p[key] && vis.has(p[key])) next[key] = p[key] as Visibility;
    }
    if (Object.keys(next).length) {
      await db
        .update(privacySettings)
        .set(next)
        .where(eq(privacySettings.userId, user.id));
    }
  }
  const [fresh] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
  return json({ user: await serializeMe(fresh) });
}

export async function handleHeartbeat(user: AuthedUser) {
  await db
    .update(users)
    .set({ isOnline: true, lastSeen: new Date() })
    .where(eq(users.id, user.id));
  return json({ ok: true });
}

export async function handleTyping(user: AuthedUser, req: Request) {
  const body = await req.json().catch(() => null);
  const conversationId = sanitizeText(body?.conversationId, 80);
  if (!conversationId) return error("گفتگو مشخص نیست.");
  const ids = await (await import("@/lib/server")).memberIds(conversationId);
  if (!ids.includes(user.id)) return error("دسترسی ندارید.", 403);
  await emitEvent({
    type: "typing",
    conversationId,
    userId: user.id,
    displayName: user.displayName,
    userIds: ids,
  });
  return json({ ok: true });
}

export async function handlePublicUser(me: AuthedUser, id: string) {
  const [user] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!user) return error("کاربر پیدا نشد.", 404);
  const [privacy] = await db
    .select()
    .from(privacySettings)
    .where(eq(privacySettings.userId, user.id))
    .limit(1);
  const friend = await areFriends(me.id, user.id);
  const [stats] = await db.select().from(gameStats).where(eq(gameStats.userId, user.id)).limit(1);
  return json({
    user: {
      ...publicUser(user, {
        friend,
        isSelf: me.id === user.id,
        privacy: privacy
          ? {
              lastSeen: privacy.lastSeen,
              profilePhoto: privacy.profilePhoto,
              onlineStatus: privacy.onlineStatus,
            }
          : undefined,
      }),
      bio: user.bio,
      stats,
      isFriend: friend,
    },
  });
}

export async function handleSpendCoins(user: AuthedUser, req: Request) {
  const body = await req.json().catch(() => null);
  const item = sanitizeText(body?.item, 40);
  const catalog: Record<string, { cost: number; theme: string }> = {
    ember: { cost: 200, theme: "ember" },
    forest: { cost: 200, theme: "forest" },
    royal: { cost: 500, theme: "royal" },
  };
  const found = catalog[item];
  if (!found) return error("آیتم نامعتبر است.");
  const unlocked = new Set(user.unlockedThemes.split(",").filter(Boolean));
  if (unlocked.has(found.theme)) return error("این تم از قبل باز شده.");
  const [wallet] = await db.select().from(coins).where(eq(coins.userId, user.id)).limit(1);
  const balance = wallet?.balance ?? 0;
  if (balance < found.cost) return error("لومن‌کوین کافی نیست.");
  const next = balance - found.cost;
  await db.update(coins).set({ balance: next }).where(eq(coins.userId, user.id));
  await db.insert(coinTransactions).values({
    userId: user.id,
    amount: -found.cost,
    reason: `unlock:${found.theme}`,
  });
  unlocked.add(found.theme);
  await db
    .update(users)
    .set({ unlockedThemes: [...unlocked].join(","), theme: found.theme })
    .where(eq(users.id, user.id));
  const [fresh] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
  return json({ user: await serializeMe(fresh), coins: next });
}

export async function handleCoins(user: AuthedUser) {
  const [wallet] = await db.select().from(coins).where(eq(coins.userId, user.id)).limit(1);
  const txs = await db
    .select()
    .from(coinTransactions)
    .where(eq(coinTransactions.userId, user.id));
  return json({
    balance: wallet?.balance ?? 0,
    transactions: txs.slice(-30).reverse(),
  });
}

export async function handleNotifications(user: AuthedUser) {
  const rows = await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, user.id));
  rows.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  return json({ notifications: rows.slice(0, 80) });
}

export async function handleReadNotifications(user: AuthedUser) {
  await db.update(notifications).set({ read: true }).where(eq(notifications.userId, user.id));
  return json({ ok: true });
}


