import { and, desc, eq, inArray, or } from "drizzle-orm";
import { db } from "@/db";
import {
  coins,
  gameMatches,
  gameStats,
  notifications,
  users,
} from "@/db/schema";
import {
  applyGameResult,
  AuthedUser,
  emitEvent,
  error,
  json,
  sanitizeText,
} from "@/lib/server";

const MULTIPLAYER = new Set(["tictactoe", "rps"]);

function emptyState(gameType: string) {
  if (gameType === "tictactoe") return { board: Array(9).fill(""), x: null as string | null };
  if (gameType === "rps") return { p1: null as string | null, p2: null as string | null };
  return {};
}

function winnerTtt(board: string[]) {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];
  for (const [a, b, c] of lines) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  if (board.every(Boolean)) return "draw";
  return null;
}

function rpsWinner(a: string, b: string) {
  if (a === b) return "draw";
  if (
    (a === "rock" && b === "scissors") ||
    (a === "paper" && b === "rock") ||
    (a === "scissors" && b === "paper")
  ) {
    return "p1";
  }
  return "p2";
}

function sanitizeMatch(
  match: typeof gameMatches.$inferSelect,
  userId: string,
) {
  const state = { ...(match.state as Record<string, unknown>) };
  if (match.gameType === "rps" && match.status === "active") {
    const p1 = state.p1 as string | null;
    const p2 = state.p2 as string | null;
    if (!p1 || !p2) {
      if (userId === match.player1Id) state.p2 = p2 ? "chosen" : null;
      else state.p1 = p1 ? "chosen" : null;
    }
  }
  return { ...match, state };
}

export async function handleCreateMatch(me: AuthedUser, req: Request) {
  const body = await req.json().catch(() => null);
  const gameType = sanitizeText(body?.gameType, 20);
  const opponentId = sanitizeText(body?.opponentId, 80);
  if (!MULTIPLAYER.has(gameType)) return error("این بازی چندنفره نیست.");
  if (!opponentId || opponentId === me.id) return error("رقیب نامعتبر است.");
  const [peer] = await db.select().from(users).where(eq(users.id, opponentId)).limit(1);
  if (!peer || peer.isSystem) return error("کاربر پیدا نشد.");

  const state = emptyState(gameType);
  if (gameType === "tictactoe") {
    (state as { x: string | null }).x = me.id;
  }

  const [match] = await db
    .insert(gameMatches)
    .values({
      gameType,
      status: "pending",
      player1Id: me.id,
      player2Id: opponentId,
      turnUserId: me.id,
      state,
    })
    .returning();

  await db.insert(notifications).values({
    userId: opponentId,
    type: "game",
    title: "دعوت به بازی",
    body: `${me.displayName} شما را به ${gameType === "rps" ? "سنگ کاغذ قیچی" : "دوز"} دعوت کرد`,
    data: { matchId: match.id, gameType },
  });
  await emitEvent({
    type: "match",
    matchId: match.id,
    userIds: [me.id, opponentId],
  });
  return json({ match: sanitizeMatch(match, me.id) });
}

export async function handleListMatches(me: AuthedUser) {
  const rows = await db
    .select()
    .from(gameMatches)
    .where(or(eq(gameMatches.player1Id, me.id), eq(gameMatches.player2Id, me.id)))
    .orderBy(desc(gameMatches.updatedAt))
    .limit(40);
  const ids = [...new Set(rows.flatMap((r) => [r.player1Id, r.player2Id]))];
  const people = ids.length
    ? await db.select().from(users).where(inArray(users.id, ids))
    : [];
  const map = new Map(people.map((p) => [p.id, { id: p.id, displayName: p.displayName, username: p.username, avatarUrl: p.avatarUrl }]));
  return json({
    matches: rows.map((m) => ({
      ...sanitizeMatch(m, me.id),
      player1: map.get(m.player1Id),
      player2: map.get(m.player2Id),
    })),
  });
}

export async function handleGetMatch(me: AuthedUser, id: string) {
  const [match] = await db.select().from(gameMatches).where(eq(gameMatches.id, id)).limit(1);
  if (!match) return error("بازی پیدا نشد.", 404);
  if (match.player1Id !== me.id && match.player2Id !== me.id) return error("دسترسی ندارید.", 403);
  const [p1] = await db.select().from(users).where(eq(users.id, match.player1Id)).limit(1);
  const [p2] = await db.select().from(users).where(eq(users.id, match.player2Id)).limit(1);
  return json({
    match: {
      ...sanitizeMatch(match, me.id),
      player1: p1
        ? { id: p1.id, displayName: p1.displayName, username: p1.username, avatarUrl: p1.avatarUrl }
        : null,
      player2: p2
        ? { id: p2.id, displayName: p2.displayName, username: p2.username, avatarUrl: p2.avatarUrl }
        : null,
    },
  });
}

export async function handleMatchAction(me: AuthedUser, id: string, action: string, req: Request) {
  const [match] = await db.select().from(gameMatches).where(eq(gameMatches.id, id)).limit(1);
  if (!match) return error("بازی پیدا نشد.", 404);
  if (match.player1Id !== me.id && match.player2Id !== me.id) return error("دسترسی ندارید.", 403);

  if (action === "accept") {
    if (match.player2Id !== me.id) return error("فقط دعوت‌شده می‌تواند بپذیرد.", 403);
    if (match.status !== "pending") return error("این دعوت دیگر معتبر نیست.");
    const [updated] = await db
      .update(gameMatches)
      .set({ status: "active", updatedAt: new Date() })
      .where(eq(gameMatches.id, id))
      .returning();
    await emitEvent({ type: "match", matchId: id, userIds: [match.player1Id, match.player2Id] });
    return json({ match: sanitizeMatch(updated, me.id) });
  }

  if (action === "decline") {
    if (match.player2Id !== me.id) return error("اجازه ندارید.", 403);
    if (match.status !== "pending") return error("این دعوت دیگر معتبر نیست.");
    await db.update(gameMatches).set({ status: "declined", updatedAt: new Date() }).where(eq(gameMatches.id, id));
    await emitEvent({ type: "match", matchId: id, userIds: [match.player1Id, match.player2Id] });
    return json({ ok: true });
  }

  if (action === "move") {
    if (match.status !== "active") return error("بازی فعال نیست.");
    const body = await req.json().catch(() => null);
    const state = { ...(match.state as Record<string, unknown>) };

    if (match.gameType === "tictactoe") {
      const index = Number(body?.index);
      if (!Number.isInteger(index) || index < 0 || index > 8) return error("حرکت نامعتبر است.");
      if (match.turnUserId !== me.id) return error("نوبت شما نیست.");
      const board = [...((state.board as string[]) ?? Array(9).fill(""))];
      if (board[index]) return error("این خانه پر است.");
      const mark = state.x === me.id ? "X" : "O";
      board[index] = mark;
      state.board = board;
      const w = winnerTtt(board);
      let status: "pending" | "active" | "finished" | "declined" = "active";
      let winnerId: string | null = null;
      let turnUserId: string | null =
        me.id === match.player1Id ? match.player2Id : match.player1Id;
      if (w === "draw") {
        status = "finished";
        winnerId = "draw";
        turnUserId = null;
      } else if (w) {
        status = "finished";
        winnerId = w === "X" ? (state.x as string) : me.id === state.x ? (me.id === match.player1Id ? match.player2Id : match.player1Id) : me.id;
        const xId = state.x as string;
        winnerId = w === "X" ? xId : xId === match.player1Id ? match.player2Id : match.player1Id;
        turnUserId = null;
      }
      const [updated] = await db
        .update(gameMatches)
        .set({ state, status, winnerId, turnUserId, updatedAt: new Date() })
        .where(eq(gameMatches.id, id))
        .returning();
      if (status === "finished") await settle(match, winnerId);
      await emitEvent({ type: "match", matchId: id, userIds: [match.player1Id, match.player2Id] });
      return json({ match: sanitizeMatch(updated, me.id) });
    }

    if (match.gameType === "rps") {
      const move = sanitizeText(body?.move, 16);
      if (!["rock", "paper", "scissors"].includes(move)) return error("حرکت نامعتبر است.");
      if (me.id === match.player1Id) {
        if (state.p1) return error("قبلاً انتخاب کرده‌اید.");
        state.p1 = move;
      } else {
        if (state.p2) return error("قبلاً انتخاب کرده‌اید.");
        state.p2 = move;
      }
      let status: "pending" | "active" | "finished" | "declined" = "active";
      let winnerId: string | null = null;
      if (state.p1 && state.p2) {
        const w = rpsWinner(state.p1 as string, state.p2 as string);
        status = "finished";
        winnerId = w === "draw" ? "draw" : w === "p1" ? match.player1Id : match.player2Id;
      }
      const [updated] = await db
        .update(gameMatches)
        .set({ state, status, winnerId, updatedAt: new Date() })
        .where(eq(gameMatches.id, id))
        .returning();
      if (status === "finished") await settle(match, winnerId);
      await emitEvent({ type: "match", matchId: id, userIds: [match.player1Id, match.player2Id] });
      return json({ match: sanitizeMatch(updated, me.id) });
    }
  }

  return error("عمل نامعتبر است.");
}

async function settle(
  match: typeof gameMatches.$inferSelect,
  winnerId: string | null,
) {
  if (winnerId === "draw") {
    await applyGameResult(match.player1Id, "draw", `match:${match.gameType}`);
    await applyGameResult(match.player2Id, "draw", `match:${match.gameType}`);
    return;
  }
  if (!winnerId) return;
  const loser = winnerId === match.player1Id ? match.player2Id : match.player1Id;
  await applyGameResult(winnerId, "win", `match:${match.gameType}`);
  await applyGameResult(loser, "loss", `match:${match.gameType}`);
}

export async function handleSolo(me: AuthedUser, req: Request) {
  const body = await req.json().catch(() => null);
  const gameType = sanitizeText(body?.gameType, 24);
  const result = sanitizeText(body?.result, 10) as "win" | "loss" | "draw";
  if (!["tictactoe", "rps", "2048", "memory", "snake", "flappy"].includes(gameType)) {
    return error("بازی نامعتبر است.");
  }
  if (!["win", "loss", "draw"].includes(result)) return error("نتیجه نامعتبر است.");
  await applyGameResult(me.id, result, `solo:${gameType}`);
  const [stats] = await db.select().from(gameStats).where(eq(gameStats.userId, me.id)).limit(1);
  const [wallet] = await db.select().from(coins).where(eq(coins.userId, me.id)).limit(1);
  return json({ stats, coins: wallet?.balance ?? 0 });
}

export async function handleLeaderboard() {
  const rows = await db
    .select({
      userId: gameStats.userId,
      gamesPlayed: gameStats.gamesPlayed,
      wins: gameStats.wins,
      losses: gameStats.losses,
      draws: gameStats.draws,
      xp: gameStats.xp,
      level: gameStats.level,
      displayName: users.displayName,
      username: users.username,
      avatarUrl: users.avatarUrl,
    })
    .from(gameStats)
    .innerJoin(users, eq(users.id, gameStats.userId))
    .where(eq(users.isSystem, false))
    .orderBy(desc(gameStats.xp), desc(gameStats.wins))
    .limit(30);
  return json({ leaderboard: rows });
}

export async function handleFriends(me: AuthedUser, req: Request, method: string, extra?: string, action?: string) {
  const { friendships } = await import("@/db/schema");
  if (method === "GET") {
    const rows = await db
      .select()
      .from(friendships)
      .where(or(eq(friendships.requesterId, me.id), eq(friendships.addresseeId, me.id)));
    const ids = rows.flatMap((r) => [r.requesterId, r.addresseeId]).filter((id) => id !== me.id);
    const people = ids.length
      ? await db.select().from(users).where(inArray(users.id, ids))
      : [];
    const map = new Map(
      people.map((p) => [
        p.id,
        {
          id: p.id,
          displayName: p.displayName,
          username: p.username,
          avatarUrl: p.avatarUrl,
          isOnline: p.isOnline,
          lastSeen: p.lastSeen,
          bio: p.bio,
        },
      ]),
    );
    return json({
      friends: rows
        .filter((r) => r.status === "accepted")
        .map((r) => ({
          id: r.id,
          user: map.get(r.requesterId === me.id ? r.addresseeId : r.requesterId),
        })),
      incoming: rows
        .filter((r) => r.status === "pending" && r.addresseeId === me.id)
        .map((r) => ({ id: r.id, user: map.get(r.requesterId) })),
      outgoing: rows
        .filter((r) => r.status === "pending" && r.requesterId === me.id)
        .map((r) => ({ id: r.id, user: map.get(r.addresseeId) })),
    });
  }

  if (method === "POST" && !extra) {
    const body = await req.json().catch(() => null);
    const username = sanitizeText(body?.username, 20).toLowerCase();
    const userId = sanitizeText(body?.userId, 80);
    const [peer] = userId
      ? await db.select().from(users).where(eq(users.id, userId)).limit(1)
      : await db.select().from(users).where(eq(users.username, username)).limit(1);
    if (!peer || peer.id === me.id || peer.isSystem) return error("کاربر پیدا نشد.");

    const existing = await db
      .select()
      .from(friendships)
      .where(
        or(
          and(eq(friendships.requesterId, me.id), eq(friendships.addresseeId, peer.id)),
          and(eq(friendships.requesterId, peer.id), eq(friendships.addresseeId, me.id)),
        ),
      )
      .limit(1);
    if (existing[0]?.status === "accepted") return error("قبلاً دوست هستید.");
    if (existing[0]?.status === "pending" && existing[0].addresseeId === me.id) {
      await db.update(friendships).set({ status: "accepted" }).where(eq(friendships.id, existing[0].id));
      return json({ ok: true, accepted: true });
    }
    if (existing[0]?.status === "pending") return error("درخواست قبلاً ارسال شده.");
    if (existing[0]?.status === "blocked") return error("امکان ارسال درخواست نیست.", 403);

    await db.insert(friendships).values({
      requesterId: me.id,
      addresseeId: peer.id,
      status: "pending",
    });
    await db.insert(notifications).values({
      userId: peer.id,
      type: "friend",
      title: "درخواست دوستی",
      body: `${me.displayName} می‌خواهد با شما دوست شود`,
      data: { userId: me.id },
    });
    await emitEvent({ type: "friend", userIds: [me.id, peer.id] });
    return json({ ok: true });
  }

  if (method === "POST" && extra && action === "accept") {
    const [row] = await db.select().from(friendships).where(eq(friendships.id, extra)).limit(1);
    if (!row || row.addresseeId !== me.id) return error("درخواست پیدا نشد.", 404);
    await db.update(friendships).set({ status: "accepted" }).where(eq(friendships.id, extra));
    await emitEvent({ type: "friend", userIds: [row.requesterId, row.addresseeId] });
    return json({ ok: true });
  }
  if (method === "POST" && extra && action === "reject") {
    const [row] = await db.select().from(friendships).where(eq(friendships.id, extra)).limit(1);
    if (!row || row.addresseeId !== me.id) return error("درخواست پیدا نشد.", 404);
    await db.update(friendships).set({ status: "rejected" }).where(eq(friendships.id, extra));
    return json({ ok: true });
  }
  if (method === "DELETE" && extra) {
    const [row] = await db.select().from(friendships).where(eq(friendships.id, extra)).limit(1);
    if (!row) return error("یافت نشد.", 404);
    if (row.requesterId !== me.id && row.addresseeId !== me.id) return error("اجازه ندارید.", 403);
    await db.delete(friendships).where(eq(friendships.id, extra));
    return json({ ok: true });
  }
  return error("درخواست نامعتبر است.");
}


