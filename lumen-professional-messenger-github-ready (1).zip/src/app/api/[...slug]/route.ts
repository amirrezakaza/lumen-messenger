import { Client } from "pg";
import {
  handleCoins,
  handleForgot,
  handleHeartbeat,
  handleLogin,
  handleLogout,
  handleNotifications,
  handlePublicUser,
  handleReadNotifications,
  handleRegister,
  handleReset,
  handleSpendCoins,
  handleTyping,
  handleUpdateMe,
  serializeMe,
} from "@/server/auth-api";
import {
  handleCreateConversation,
  handleDeleteMessage,
  handleForward,
  handleGetConversation,
  handleJoinChannel,
  handleLeaveConversation,
  handleListConversations,
  handleMembers,
  handleMessages,
  handlePatchConversation,
  handlePatchMessage,
  handleReact,
  handleRead,
  handleSearch,
  handleSendMessage,
} from "@/server/chat-api";
import {
  handleCreateMatch,
  handleFriends,
  handleGetMatch,
  handleLeaderboard,
  handleListMatches,
  handleMatchAction,
  handleSolo,
} from "@/server/games-api";
import { error, getCurrentUser, json, requireUser } from "@/lib/server";
import { ensureSeed } from "@/db/seed";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

type Ctx = { params: Promise<{ slug: string[] }> };

async function pathOf(ctx: Ctx) {
  const { slug } = await ctx.params;
  return slug.join("/");
}

export async function GET(req: Request, ctx: Ctx) {
  const path = await pathOf(ctx);
  try {
    await ensureSeed();
  } catch {
    /* schema may not be pushed yet */
  }

  if (path === "realtime") return handleRealtime();

  const { user, err } = await requireUser();
  if (!user) return err;

  if (path === "auth/me") return json({ user: await serializeMe(user) });
  if (path === "conversations") return handleListConversations(user);
  if (path === "friends") return handleFriends(user, req, "GET");
  if (path === "search") return handleSearch(user, req);
  if (path === "notifications") return handleNotifications(user);
  if (path === "coins") return handleCoins(user);
  if (path === "games/matches") return handleListMatches(user);
  if (path === "games/leaderboard") return handleLeaderboard();

  let m = path.match(/^conversations\/([^/]+)$/);
  if (m) return handleGetConversation(user, m[1]);
  m = path.match(/^conversations\/([^/]+)\/messages$/);
  if (m) return handleMessages(user, m[1], req);
  m = path.match(/^users\/([^/]+)$/);
  if (m) return handlePublicUser(user, m[1]);
  m = path.match(/^games\/matches\/([^/]+)$/);
  if (m) return handleGetMatch(user, m[1]);

  return error("مسیر پیدا نشد.", 404);
}

export async function POST(req: Request, ctx: Ctx) {
  const path = await pathOf(ctx);
  try {
    await ensureSeed();
  } catch {
    /* ignore */
  }

  if (path === "auth/register") return handleRegister(req);
  if (path === "auth/login") return handleLogin(req);
  if (path === "auth/forgot") return handleForgot(req);
  if (path === "auth/reset") return handleReset(req);

  const { user, err } = await requireUser();
  if (!user) return err;

  if (path === "auth/logout") return handleLogout(user);
  if (path === "auth/heartbeat") return handleHeartbeat(user);
  if (path === "auth/typing") return handleTyping(user, req);
  if (path === "conversations") return handleCreateConversation(user, req);
  if (path === "friends") return handleFriends(user, req, "POST");
  if (path === "games/matches") return handleCreateMatch(user, req);
  if (path === "games/solo") return handleSolo(user, req);
  if (path === "coins/spend") return handleSpendCoins(user, req);
  if (path === "notifications/read") return handleReadNotifications(user);

  let m = path.match(/^conversations\/([^/]+)\/messages$/);
  if (m) return handleSendMessage(user, m[1], req);
  m = path.match(/^conversations\/([^/]+)\/read$/);
  if (m) return handleRead(user, m[1]);
  m = path.match(/^conversations\/([^/]+)\/members$/);
  if (m) return handleMembers(user, m[1], req, "POST");
  m = path.match(/^conversations\/([^/]+)\/join$/);
  if (m) return handleJoinChannel(user, m[1]);
  m = path.match(/^messages\/([^/]+)\/react$/);
  if (m) return handleReact(user, m[1], req);
  m = path.match(/^messages\/([^/]+)\/forward$/);
  if (m) return handleForward(user, m[1], req);
  m = path.match(/^games\/matches\/([^/]+)\/(accept|decline|move)$/);
  if (m) return handleMatchAction(user, m[1], m[2], req);
  m = path.match(/^friends\/([^/]+)\/(accept|reject)$/);
  if (m) return handleFriends(user, req, "POST", m[1], m[2]);

  return error("مسیر پیدا نشد.", 404);
}

export async function PATCH(req: Request, ctx: Ctx) {
  const path = await pathOf(ctx);
  const { user, err } = await requireUser();
  if (!user) return err;

  if (path === "auth/me") return handleUpdateMe(user, req);

  let m = path.match(/^conversations\/([^/]+)$/);
  if (m) return handlePatchConversation(user, m[1], req);
  m = path.match(/^conversations\/([^/]+)\/members$/);
  if (m) return handleMembers(user, m[1], req, "PATCH");
  m = path.match(/^messages\/([^/]+)$/);
  if (m) return handlePatchMessage(user, m[1], req);

  return error("مسیر پیدا نشد.", 404);
}

export async function DELETE(req: Request, ctx: Ctx) {
  const path = await pathOf(ctx);
  const { user, err } = await requireUser();
  if (!user) return err;

  let m = path.match(/^conversations\/([^/]+)$/);
  if (m) return handleLeaveConversation(user, m[1]);
  m = path.match(/^conversations\/([^/]+)\/members\/([^/]+)$/);
  if (m) return handleMembers(user, m[1], req, "DELETE", m[2]);
  m = path.match(/^messages\/([^/]+)$/);
  if (m) return handleDeleteMessage(user, m[1]);
  m = path.match(/^friends\/([^/]+)$/);
  if (m) return handleFriends(user, req, "DELETE", m[1]);

  return error("مسیر پیدا نشد.", 404);
}

async function handleRealtime() {
  const user = await getCurrentUser();
  if (!user) return error("نشست نامعتبر است.", 401);

  const encoder = new TextEncoder();
  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();
  await client.query("LISTEN lumen_event");

  let closed = false;
  const stream = new ReadableStream({
    start(controller) {
      const send = (data: unknown) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(data)}\n\n`));
        } catch {
          closed = true;
        }
      };
      send({ type: "hello", userId: user.id });

      const onNotify = (msg: { payload?: string }) => {
        if (!msg.payload) return;
        try {
          const event = JSON.parse(msg.payload) as {
            type?: string;
            userIds?: string[];
            userId?: string;
          };
          if (Array.isArray(event.userIds) && !event.userIds.includes(user.id)) return;
          if (event.type === "presence" && event.userId === user.id) return;
          send(event);
        } catch {
          /* ignore bad payloads */
        }
      };

      client.on("notification", onNotify);
      const ping = setInterval(() => send({ type: "ping" }), 25000);

      const shutdown = () => {
        if (closed) return;
        closed = true;
        clearInterval(ping);
        client.removeListener("notification", onNotify);
        void client.query("UNLISTEN lumen_event").finally(() => {
          void client.end();
        });
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };

      client.on("error", shutdown);
    },
    cancel() {
      closed = true;
      void client.query("UNLISTEN lumen_event").finally(() => {
        void client.end();
      });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
