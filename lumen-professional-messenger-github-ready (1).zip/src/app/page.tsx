import { HomeGate } from "@/components/lumen/HomeGate";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <HomeGate />;
}
