export default function OfflinePage() {
  return (
    <main className="grid min-h-dvh place-items-center px-6 text-center">
      <div className="glass max-w-sm rounded-3xl p-8">
        <p className="text-sm tracking-[0.3em] text-[color:var(--gold)]">LUMEN</p>
        <h1 className="mt-3 text-2xl font-bold">آفلاین هستید</h1>
        <p className="mt-2 text-sm text-[color:var(--muted)]">
          اتصال اینترنت برقرار نیست. پس از وصل شدن، لومن دوباره زنده می‌شود.
        </p>
      </div>
    </main>
  );
}
