"use client";

import { useState, type FormEvent } from "react";
import { api, fileToDataUrl, type Me } from "@/lib/client";
import { Icon, LumenMark, Spinner } from "./ui";

type Mode = "login" | "register" | "forgot" | "reset";

export function AuthScreen({ onAuthed }: { onAuthed: (user: Me) => void }) {
  const [mode, setMode] = useState<Mode>("login");
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [remember, setRemember] = useState(true);
  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [demoCode, setDemoCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [googleHint, setGoogleHint] = useState("");

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      if (mode === "login") {
        const data = await api<{ user: Me }>("auth/login", {
          method: "POST",
          body: JSON.stringify({ identifier, password, remember }),
        });
        onAuthed(data.user);
        return;
      }
      if (mode === "register") {
        const data = await api<{ user: Me }>("auth/register", {
          method: "POST",
          body: JSON.stringify({
            displayName,
            username,
            email: email || null,
            phone: phone || null,
            password,
            avatarUrl,
            remember,
          }),
        });
        onAuthed(data.user);
        return;
      }
      if (mode === "forgot") {
        const data = await api<{ demoCode?: string; message: string }>("auth/forgot", {
          method: "POST",
          body: JSON.stringify({ email: email || identifier }),
        });
        setDemoCode(data.demoCode || "");
        setMode("reset");
        return;
      }
      const data = await api<{ ok: boolean }>("auth/reset", {
        method: "POST",
        body: JSON.stringify({ email: email || identifier, code, password }),
      });
      if (data.ok) {
        setMode("login");
        setPassword("");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "خطا");
    } finally {
      setLoading(false);
    }
  }

  async function demo() {
    setIdentifier("luna@lumen.app");
    setPassword("LumenDemo1!");
    setError("");
    setLoading(true);
    try {
      const data = await api<{ user: Me }>("auth/login", {
        method: "POST",
        body: JSON.stringify({ identifier: "luna@lumen.app", password: "LumenDemo1!", remember: true }),
      });
      onAuthed(data.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : "ورود آزمایشی ناموفق بود");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="relative min-h-dvh overflow-x-hidden px-4 py-8 sm:px-6">
      <div
        className="pointer-events-none absolute inset-0 opacity-70"
        style={{
          backgroundImage: "url(/brand/auth-glow.jpg)",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      <div className="pointer-events-none absolute inset-0 bg-[#07080f]/70" />
      <div className="orb right-[-80px] top-10 h-52 w-52 bg-[#8b7cff]" />
      <div className="orb left-[-60px] bottom-10 h-40 w-40 bg-[#4ee1ff]" />

      <div className="relative mx-auto flex min-h-[calc(100dvh-4rem)] w-full max-w-md flex-col justify-center">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 grid place-items-center">
            <LumenMark size={72} />
          </div>
          <p className="text-[11px] tracking-[0.42em] text-[color:var(--gold)]">LUMEN</p>
          <h1 className="mt-2 text-3xl font-extrabold">نورِ گفتگو</h1>
          <p className="mt-2 text-sm text-[color:var(--muted)]">
            پیام‌رسان مینیمال برای مکالمه، گروه، کانال و بازی
          </p>
        </div>

        <form onSubmit={submit} className="glass rounded-[28px] p-5 sm:p-6">
          <div className="mb-5 flex rounded-2xl bg-white/5 p-1 text-sm">
            {(["login", "register"] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => {
                  setMode(m);
                  setError("");
                }}
                className={`flex-1 rounded-xl py-2 font-semibold ${mode === m || (mode !== "login" && mode !== "register" && m === "login") ? "bg-white/10" : "text-[color:var(--muted)]"}`}
              >
                {m === "login" ? "ورود" : "ثبت‌نام"}
              </button>
            ))}
          </div>

          {error ? (
            <div className="mb-4 rounded-2xl border border-[#ff6b8a]/30 bg-[#ff6b8a]/10 px-3 py-2 text-sm text-[#ffb1c0]">
              {error}
            </div>
          ) : null}

          {mode === "register" ? (
            <>
              <label className="mb-3 block">
                <span className="mb-1 block text-xs text-[color:var(--muted)]">نام</span>
                <input className="field" value={displayName} onChange={(e) => setDisplayName(e.target.value)} required />
              </label>
              <label className="mb-3 block">
                <span className="mb-1 block text-xs text-[color:var(--muted)]">نام کاربری</span>
                <input className="field ltr" value={username} onChange={(e) => setUsername(e.target.value)} required />
              </label>
              <label className="mb-3 block">
                <span className="mb-1 block text-xs text-[color:var(--muted)]">ایمیل</span>
                <input className="field ltr" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
              </label>
              <label className="mb-3 block">
                <span className="mb-1 block text-xs text-[color:var(--muted)]">شماره موبایل</span>
                <input className="field ltr" value={phone} onChange={(e) => setPhone(e.target.value)} />
              </label>
              <label className="mb-3 block">
                <span className="mb-1 block text-xs text-[color:var(--muted)]">عکس پروفایل</span>
                <input
                  className="field"
                  type="file"
                  accept="image/*"
                  onChange={async (e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    try {
                      setAvatarUrl(await fileToDataUrl(f, 700_000));
                    } catch (err) {
                      setError(err instanceof Error ? err.message : "آپلود ناموفق");
                    }
                  }}
                />
              </label>
            </>
          ) : null}

          {mode === "login" ? (
            <label className="mb-3 block">
              <span className="mb-1 block text-xs text-[color:var(--muted)]">ایمیل، شماره یا نام کاربری</span>
              <input className="field ltr" value={identifier} onChange={(e) => setIdentifier(e.target.value)} required />
            </label>
          ) : null}

          {mode === "forgot" || mode === "reset" ? (
            <label className="mb-3 block">
              <span className="mb-1 block text-xs text-[color:var(--muted)]">ایمیل</span>
              <input className="field ltr" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </label>
          ) : null}

          {mode === "reset" ? (
            <label className="mb-3 block">
              <span className="mb-1 block text-xs text-[color:var(--muted)]">کد بازیابی</span>
              <input className="field ltr" value={code} onChange={(e) => setCode(e.target.value)} required />
            </label>
          ) : null}

          {demoCode ? (
            <p className="mb-3 rounded-2xl bg-white/5 px-3 py-2 text-xs text-[color:var(--gold)]">
              کد نمایشی: {demoCode}
            </p>
          ) : null}

          {mode !== "forgot" ? (
            <label className="mb-3 block">
              <span className="mb-1 block text-xs text-[color:var(--muted)]">رمز عبور</span>
              <div className="relative">
                <input
                  className="field ltr pl-16"
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button
                  type="button"
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-[color:var(--muted)]"
                  onClick={() => setShowPass((v) => !v)}
                >
                  {showPass ? "پنهان" : "نمایش"}
                </button>
              </div>
            </label>
          ) : null}

          {mode === "login" || mode === "register" ? (
            <label className="mb-4 flex items-center gap-2 text-sm text-[color:var(--muted)]">
              <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
              مرا به خاطر بسپار
            </label>
          ) : null}

          {mode === "login" ? (
            <button type="button" className="mb-4 text-sm text-[color:var(--accent-2)]" onClick={() => setMode("forgot")}>
              فراموشی رمز عبور
            </button>
          ) : null}

          <button className="btn-primary flex w-full items-center justify-center gap-2" disabled={loading}>
            {loading ? <Spinner /> : null}
            {mode === "login"
              ? "ورود"
              : mode === "register"
                ? "ساخت حساب"
                : mode === "forgot"
                  ? "ارسال کد"
                  : "تغییر رمز"}
          </button>

          <button
            type="button"
            onClick={() =>
              setGoogleHint("ورود گوگل نیاز به پیکربندی کلید در سمت سرور دارد و در این محیط فعال نیست.")
            }
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-white/10 py-3 text-sm"
          >
            ادامه با Google
          </button>
          {googleHint ? <p className="mt-2 text-xs text-[color:var(--muted)]">{googleHint}</p> : null}

          <button type="button" onClick={demo} className="mt-4 w-full text-sm text-[color:var(--gold)]">
            ورود آزمایشی با حساب لونا
          </button>
        </form>
        <p className="mt-6 text-center text-xs text-[color:var(--muted)]">
          با ورود، تجربهٔ نصب به‌عنوان اپ روی موبایل و دسکتاپ در دسترس است.
        </p>
      </div>
    </main>
  );
}
