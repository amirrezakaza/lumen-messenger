"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  api,
  clock,
  fileToDataUrl,
  playPing,
  timeAgo,
  type ChatMessage,
  type Conversation,
  type Me,
} from "@/lib/client";
import { GamesHub } from "./Games";
import {
  FriendsView,
  NotificationsView,
  ProfileView,
  SearchView,
  SettingsView,
  UserModal,
} from "./Social";
import { Avatar, Empty, Icon, LumenMark, Modal, Spinner } from "./ui";

type Tab = "chats" | "games" | "friends" | "profile";
type Overlay = "none" | "search" | "settings" | "notifications" | "new";

const EMOJIS = ["😀", "😂", "😍", "🔥", "👍", "👏", "🎉", "🌸", "✨", "💜", "🤝", "🌙"];

export function Messenger({ user, setUser }: { user: Me; setUser: (u: Me | null) => void }) {
  const [tab, setTab] = useState<Tab>("chats");
  const [overlay, setOverlay] = useState<Overlay>("none");
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [profileUser, setProfileUser] = useState<string | null>(null);
  const [install, setInstall] = useState<BeforeInstallPromptEvent | null>(null);
  const [notifAsk, setNotifAsk] = useState(false);
  const [iosHint, setIosHint] = useState(false);

  const loadChats = useCallback(async () => {
    const d = await api<{ conversations: Conversation[] }>("conversations");
    setConversations(d.conversations);
    const unread = d.conversations.reduce((n, c) => n + c.unread, 0);
    if ("setAppBadge" in navigator) {
      void (navigator as Navigator & { setAppBadge?: (n: number) => Promise<void> }).setAppBadge?.(unread);
    }
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = user.theme || "aurora";
  }, [user.theme]);

  useEffect(() => {
    void loadChats();
    const hb = setInterval(() => {
      void api("auth/heartbeat", { method: "POST", body: "{}" });
    }, 12000);
    const es = new EventSource("/api/realtime");
    es.onmessage = (ev) => {
      try {
        const data = JSON.parse(ev.data) as { type?: string; conversationId?: string };
        if (data.type === "ping" || data.type === "hello") return;
        void loadChats();
        window.dispatchEvent(new CustomEvent("lumen-event", { detail: data }));
        if (data.type === "message" && document.hidden) {
          playPing();
          if (typeof Notification !== "undefined" && Notification.permission === "granted") {
            new Notification("Lumen", { body: "پیام جدید", icon: "/icons/icon-192.png", tag: data.conversationId });
          }
        }
      } catch {
        /* ignore */
      }
    };
    return () => {
      clearInterval(hb);
      es.close();
    };
  }, [loadChats]);

  useEffect(() => {
    const onInstall = (e: Event) => {
      e.preventDefault();
      setInstall(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onInstall);
    const standalone = window.matchMedia("(display-mode: standalone)").matches;
    const ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
    if (ios && !standalone) setIosHint(true);
    if (typeof Notification !== "undefined" && Notification.permission === "default") setNotifAsk(true);
    return () => window.removeEventListener("beforeinstallprompt", onInstall);
  }, []);

  async function openDirect(username: string) {
    const d = await api<{ conversation: { id: string } }>("conversations", {
      method: "POST",
      body: JSON.stringify({ type: "direct", username }),
    });
    setTab("chats");
    setOverlay("none");
    setActiveId(d.conversation.id);
    await loadChats();
  }

  async function logout() {
    await api("auth/logout", { method: "POST", body: "{}" });
    setUser(null);
  }

  const active = conversations.find((c) => c.id === activeId) ?? null;
  const showChat = Boolean(activeId);
  const mobileChat = showChat && tab === "chats";

  return (
    <div className="lumen-app flex bg-[color:var(--bg)]">
      <aside className="hidden w-[76px] shrink-0 flex-col items-center gap-2 border-l border-white/5 py-4 lg:flex">
        <LumenMark size={42} />
        <Rail tab={tab} setTab={setTab} unread={conversations.reduce((n, c) => n + c.unread, 0)} />
        <div className="mt-auto flex flex-col items-center gap-2">
          <button onClick={() => setOverlay("notifications")} className="relative p-2 text-[color:var(--muted)]">
            <Icon name="bell" />
            {user.unreadNotifications ? (
              <span className="absolute left-1 top-1 h-2 w-2 rounded-full bg-[#ff6b8a]" />
            ) : null}
          </button>
          <button onClick={() => setOverlay("settings")} className="p-2 text-[color:var(--muted)]">
            <Icon name="settings" />
          </button>
        </div>
      </aside>

      <section
        className={`flex min-w-0 flex-1 flex-col border-l border-white/5 lg:max-w-[380px] ${mobileChat ? "hidden lg:flex" : "flex"}`}
      >
        {tab === "chats" && overlay === "none" ? (
          <ChatList
            me={user}
            conversations={conversations}
            activeId={activeId}
            onOpen={(id) => setActiveId(id)}
            onSearch={() => setOverlay("search")}
            onNew={() => setOverlay("new")}
            onNotif={() => setOverlay("notifications")}
            onReload={loadChats}
          />
        ) : null}
        {tab === "games" ? (
          <GamesHub
            me={user}
            onCoins={(n, stats) => setUser({ ...user, coins: n, stats: stats ?? user.stats })}
          />
        ) : null}
        {tab === "friends" ? (
          <FriendsView onOpenUser={setProfileUser} onMessage={(u) => void openDirect(u)} />
        ) : null}
        {tab === "profile" ? <ProfileView me={user} setMe={setUser} onLogout={() => void logout()} /> : null}
        {overlay === "search" ? (
          <SearchView
            onOpenChat={(id) => {
              setOverlay("none");
              setTab("chats");
              setActiveId(id);
            }}
            onOpenUser={setProfileUser}
          />
        ) : null}
        {overlay === "settings" ? <SettingsView me={user} setMe={setUser} /> : null}
        {overlay === "notifications" ? <NotificationsView /> : null}
        {overlay === "new" ? (
          <NewConversation
            onCreated={(id) => {
              setOverlay("none");
              setTab("chats");
              setActiveId(id);
              void loadChats();
            }}
            onClose={() => setOverlay("none")}
          />
        ) : null}

        <nav className="flex border-t border-white/5 bg-[#07080f]/90 px-2 py-1 lg:hidden" style={{ paddingBottom: "calc(8px + var(--safe-b))" }}>
          {(
            [
              ["chats", "گفتگوها", "chats"],
              ["games", "بازی", "games"],
              ["friends", "دوستان", "friends"],
              ["profile", "من", "user"],
            ] as const
          ).map(([k, label, icon]) => (
            <button
              key={k}
              onClick={() => {
                setTab(k);
                setOverlay("none");
                if (k !== "chats") setActiveId(null);
              }}
              className={`relative flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] ${tab === k && overlay === "none" ? "text-white" : "text-[color:var(--muted)]"}`}
            >
              <Icon name={icon} size={20} />
              {label}
            </button>
          ))}
        </nav>
      </section>

      <section className={`min-w-0 flex-1 ${mobileChat ? "flex" : "hidden lg:flex"} flex-col`}>
        {activeId ? (
          <ChatView
            me={user}
            conversationId={activeId}
            summary={active}
            onBack={() => setActiveId(null)}
            onReloadList={loadChats}
            onProfile={setProfileUser}
          />
        ) : (
          <div className="hidden h-full place-items-center lg:grid">
            <div className="text-center">
              <LumenMark size={72} />
              <p className="mt-4 text-lg font-bold">یک گفتگو را انتخاب کنید</p>
              <p className="mt-1 text-sm text-[color:var(--muted)]">یا از بالا گفتگوی تازه بسازید</p>
            </div>
          </div>
        )}
      </section>

      <UserModal
        id={profileUser}
        onClose={() => setProfileUser(null)}
        onMessage={(u) => {
          setProfileUser(null);
          void openDirect(u);
        }}
      />

      {(install || iosHint || notifAsk) && (
        <div className="fixed bottom-20 left-3 right-3 z-40 mx-auto max-w-md rounded-2xl border border-white/10 bg-[#12141e]/95 p-3 text-sm lg:bottom-6">
          {install ? (
            <button
              className="w-full text-right"
              onClick={async () => {
                await install.prompt();
                setInstall(null);
              }}
            >
              نصب Lumen روی دستگاه
            </button>
          ) : null}
          {iosHint ? <p>در iPhone از Share → Add to Home Screen استفاده کنید.</p> : null}
          {notifAsk ? (
            <button
              className="mt-1 text-[color:var(--accent-2)]"
              onClick={async () => {
                await Notification.requestPermission();
                setNotifAsk(false);
              }}
            >
              فعال‌سازی اعلان‌ها
            </button>
          ) : null}
        </div>
      )}
    </div>
  );
}

function Rail({
  tab,
  setTab,
  unread,
}: {
  tab: Tab;
  setTab: (t: Tab) => void;
  unread: number;
}) {
  const items: { k: Tab; icon: "chats" | "games" | "friends" | "user"; label: string }[] = [
    { k: "chats", icon: "chats", label: "چت" },
    { k: "games", icon: "games", label: "بازی" },
    { k: "friends", icon: "friends", label: "دوستان" },
    { k: "profile", icon: "user", label: "من" },
  ];
  return (
    <div className="mt-6 flex flex-col gap-1">
      {items.map((it) => (
        <button
          key={it.k}
          onClick={() => setTab(it.k)}
          className={`relative rounded-2xl p-3 ${tab === it.k ? "bg-white/10 text-white" : "text-[color:var(--muted)]"}`}
        >
          <Icon name={it.icon} />
          {it.k === "chats" && unread ? (
            <span className="absolute left-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-[#ff6b8a] text-[9px]">
              {unread}
            </span>
          ) : null}
        </button>
      ))}
    </div>
  );
}

function ChatList({
  me,
  conversations,
  activeId,
  onOpen,
  onSearch,
  onNew,
  onNotif,
  onReload,
}: {
  me: Me;
  conversations: Conversation[];
  activeId: string | null;
  onOpen: (id: string) => void;
  onSearch: () => void;
  onNew: () => void;
  onNotif: () => void;
  onReload: () => void;
}) {
  const [q, setQ] = useState("");
  const filtered = conversations.filter((c) => {
    const t = (c.title || c.peer?.displayName || "").toLowerCase();
    return t.includes(q.toLowerCase());
  });

  async function action(id: string, patch: Record<string, unknown>) {
    await api(`conversations/${id}`, { method: "PATCH", body: JSON.stringify(patch) });
    onReload();
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="flex items-center gap-2 px-4 py-3">
        <div>
          <p className="text-[11px] tracking-[0.28em] text-[color:var(--gold)]">LUMEN</p>
          <h1 className="text-xl font-bold">گفتگوها</h1>
        </div>
        <div className="mr-auto flex gap-1">
          <button className="rounded-2xl p-2" onClick={onNotif}>
            <Icon name="bell" />
          </button>
          <button className="rounded-2xl p-2" onClick={onSearch}>
            <Icon name="search" />
          </button>
          <button className="rounded-2xl p-2" onClick={onNew}>
            <Icon name="plus" />
          </button>
        </div>
      </header>
      <div className="px-4 pb-2">
        <input className="field" placeholder="جستجو در گفتگوها" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="scroll-y min-h-0 flex-1 pb-2">
        {filtered.length === 0 ? <Empty title="گفتگویی نیست" hint="با + گفتگوی جدید بسازید" /> : null}
        {filtered.map((c) => (
          <button
            key={c.id}
            onClick={() => onOpen(c.id)}
            onContextMenu={(e) => {
              e.preventDefault();
              const choice = window.confirm("پین / بی‌صدا / حذف؟ OK=پین، Cancel=منو بعدی");
              if (choice) void action(c.id, { pinned: !c.pinned });
              else {
                const mute = window.confirm("بی‌صدا شود؟ Cancel یعنی حذف از لیست");
                if (mute) void action(c.id, { muted: !c.muted });
                else void action(c.id, { hidden: true });
              }
            }}
            className={`flex w-full items-center gap-3 px-4 py-3 text-right ${activeId === c.id ? "bg-white/6" : ""}`}
          >
            <Avatar
              name={c.title || "Lumen"}
              src={c.photoUrl}
              online={Boolean(c.peer?.isOnline)}
            />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="truncate font-semibold">{c.title}</span>
                {c.pinned ? <Icon name="pin" size={14} /> : null}
                {c.muted ? <Icon name="mute" size={14} /> : null}
                <span className="mr-auto text-[11px] text-[color:var(--muted)]">
                  {c.lastMessage ? timeAgo(c.lastMessage.createdAt) : ""}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <p className="truncate text-sm text-[color:var(--muted)]">
                  {c.lastMessage?.content || (c.type === "channel" ? "کانال" : "بدون پیام")}
                </p>
                {c.unread ? (
                  <span className="mr-auto grid h-5 min-w-5 place-items-center rounded-full bg-[color:var(--accent)] px-1 text-[11px]">
                    {c.unread}
                  </span>
                ) : null}
              </div>
            </div>
          </button>
        ))}
      </div>
      <p className="hidden px-4 pb-2 text-[10px] text-[color:var(--muted)] lg:block">سلام {me.displayName}</p>
    </div>
  );
}

function ChatView({
  me,
  conversationId,
  summary,
  onBack,
  onReloadList,
  onProfile,
}: {
  me: Me;
  conversationId: string;
  summary: Conversation | null;
  onBack: () => void;
  onReloadList: () => void;
  onProfile: (id: string) => void;
}) {
  const [detail, setDetail] = useState<{
    title?: string | null;
    type: string;
    role: string;
    peer?: { id: string; displayName: string; isOnline?: boolean; lastSeen?: string | null; avatarUrl?: string | null } | null;
    members: { userId: string; displayName?: string; role: string; lastReadAt: string; avatarUrl?: string | null }[];
    description?: string | null;
    photoUrl?: string | null;
  } | null>(null);
  const [msgs, setMsgs] = useState<ChatMessage[]>([]);
  const [text, setText] = useState("");
  const [reply, setReply] = useState<ChatMessage | null>(null);
  const [menu, setMenu] = useState<ChatMessage | null>(null);
  const [emoji, setEmoji] = useState(false);
  const [info, setInfo] = useState(false);
  const [typing, setTyping] = useState("");
  const [editId, setEditId] = useState<string | null>(null);
  const [forwardOpen, setForwardOpen] = useState(false);
  const [convs, setConvs] = useState<Conversation[]>([]);
  const box = useRef<HTMLDivElement | null>(null);
  const rec = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);

  const load = useCallback(async () => {
    const d = await api<{ conversation: NonNullable<typeof detail> }>(`conversations/${conversationId}`);
    setDetail(d.conversation);
    const m = await api<{ messages: ChatMessage[] }>(`conversations/${conversationId}/messages`);
    setMsgs(m.messages);
    await api(`conversations/${conversationId}/read`, { method: "POST", body: "{}" });
    onReloadList();
  }, [conversationId, onReloadList]);

  useEffect(() => {
    void load();
    const onEv = (e: Event) => {
      const data = (e as CustomEvent).detail as { type?: string; conversationId?: string; displayName?: string };
      if (data.conversationId !== conversationId) return;
      if (data.type === "typing" && data.displayName) {
        setTyping(data.displayName);
        setTimeout(() => setTyping(""), 2500);
      }
      if (data.type === "message" || data.type === "read") void load();
    };
    window.addEventListener("lumen-event", onEv);
    return () => window.removeEventListener("lumen-event", onEv);
  }, [load, conversationId]);

  useEffect(() => {
    box.current?.scrollTo({ top: box.current.scrollHeight });
  }, [msgs.length]);

  async function send(payload: Record<string, unknown>) {
    await api(`conversations/${conversationId}/messages`, {
      method: "POST",
      body: JSON.stringify({ ...payload, replyToId: reply?.id }),
    });
    setText("");
    setReply(null);
    setEmoji(false);
    await load();
  }

  async function onSend() {
    if (editId) {
      await api(`messages/${editId}`, { method: "PATCH", body: JSON.stringify({ content: text }) });
      setEditId(null);
      setText("");
      await load();
      return;
    }
    if (!text.trim()) return;
    await send({ type: "text", content: text.trim() });
  }

  const title = detail?.title || summary?.title || "گفتگو";
  const canPost = detail?.type !== "channel" || detail.role === "owner" || detail.role === "admin";

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="flex items-center gap-3 border-b border-white/5 px-3 py-2">
        <button onClick={onBack} className="lg:hidden">
          <Icon name="back" />
        </button>
        <button
          className="flex min-w-0 flex-1 items-center gap-3 text-right"
          onClick={() => {
            if (detail?.peer?.id) onProfile(detail.peer.id);
            else setInfo(true);
          }}
        >
          <Avatar name={title} src={detail?.photoUrl || summary?.photoUrl} online={Boolean(detail?.peer?.isOnline)} />
          <div className="min-w-0">
            <div className="truncate font-bold">{title}</div>
            <div className="truncate text-xs text-[color:var(--muted)]">
              {typing
                ? `${typing} در حال نوشتن...`
                : detail?.peer?.isOnline
                  ? "آنلاین"
                  : detail?.peer?.lastSeen
                    ? `آخرین بازدید ${timeAgo(detail.peer.lastSeen)}`
                    : detail?.type === "group"
                      ? `${detail.members.length} عضو`
                      : detail?.type === "channel"
                        ? `${detail.members.length} مشترک`
                        : ""}
            </div>
          </div>
        </button>
        <button onClick={() => setInfo(true)} className="p-2">
          <Icon name="more" />
        </button>
      </header>

      <div ref={box} className="scroll-y min-h-0 flex-1 space-y-2 px-3 py-3">
        {msgs.map((m) => {
          const mine = m.senderId === me.id;
          return (
            <div key={m.id} className={`msg-in flex ${mine ? "justify-start" : "justify-end"}`}>
              <button
                onContextMenu={(e) => {
                  e.preventDefault();
                  setMenu(m);
                }}
                onClick={() => setMenu(m)}
                className="max-w-[82%] rounded-3xl px-3 py-2 text-right"
                style={{
                  background: mine ? undefined : "var(--theirs)",
                  backgroundImage: mine ? "var(--mine)" : undefined,
                }}
              >
                {!mine && detail?.type !== "direct" ? (
                  <div className="mb-1 text-[11px] text-white/70">{m.sender?.displayName}</div>
                ) : null}
                {m.replyTo ? (
                  <div className="mb-1 rounded-xl bg-black/20 px-2 py-1 text-[11px] text-white/80">{m.replyTo.content}</div>
                ) : null}
                {m.forwardedFrom ? <div className="mb-1 text-[11px] text-white/70">ارسال‌شده از {m.forwardedFrom}</div> : null}
                {m.type === "image" && m.attachment ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={m.attachment} alt="" className="mb-1 max-h-56 rounded-2xl" />
                ) : null}
                {m.type === "voice" && m.attachment ? <audio controls src={m.attachment} className="my-1 w-52" /> : null}
                {m.type === "file" && m.attachment ? (
                  <a href={m.attachment} download={m.fileName || "file"} className="underline">
                    {m.fileName || "فایل"}
                  </a>
                ) : null}
                <p className="whitespace-pre-wrap break-words text-sm">{m.content}</p>
                <div className="mt-1 flex items-center gap-2 text-[10px] text-white/70">
                  <span>{clock(m.createdAt)}</span>
                  {m.editedAt ? <span>ویرایش</span> : null}
                  {mine ? <span>{m.seenBy > 0 ? "دیده شد" : "ارسال شد"}</span> : null}
                </div>
                {Object.keys(m.reactions).length ? (
                  <div className="mt-1 flex gap-1">
                    {Object.entries(m.reactions).map(([k, v]) => (
                      <span key={k} className="rounded-full bg-black/20 px-2 text-xs">
                        {k} {v.count}
                      </span>
                    ))}
                  </div>
                ) : null}
              </button>
            </div>
          );
        })}
      </div>

      {reply ? (
        <div className="flex items-center gap-2 px-3 text-xs text-[color:var(--muted)]">
          پاسخ به: {reply.content.slice(0, 40)}
          <button onClick={() => setReply(null)}>×</button>
        </div>
      ) : null}

      {canPost ? (
        <div className="border-t border-white/5 px-2 py-2" style={{ paddingBottom: "calc(8px + var(--safe-b))" }}>
          {emoji ? (
            <div className="mb-2 flex flex-wrap gap-1">
              {EMOJIS.map((e) => (
                <button key={e} onClick={() => setText((t) => t + e)} className="text-xl">
                  {e}
                </button>
              ))}
            </div>
          ) : null}
          <div className="flex items-end gap-1">
            <button className="p-2" onClick={() => setEmoji((v) => !v)}>
              <Icon name="emoji" />
            </button>
            <label className="p-2">
              <Icon name="image" />
              <input
                type="file"
                accept="image/*,application/pdf,text/plain"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  const attachment = await fileToDataUrl(f);
                  await send({
                    type: f.type.startsWith("image/") ? "image" : "file",
                    content: f.name,
                    attachment,
                    fileName: f.name,
                    mimeType: f.type,
                  });
                }}
              />
            </label>
            <textarea
              className="field min-h-11 max-h-28 flex-1 resize-none py-2"
              placeholder="پیام بنویسید"
              value={text}
              onChange={(e) => {
                setText(e.target.value);
                void api("auth/typing", { method: "POST", body: JSON.stringify({ conversationId }) });
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void onSend();
                }
              }}
            />
            {text.trim() ? (
              <button className="p-2" onClick={() => void onSend()}>
                <Icon name="send" />
              </button>
            ) : (
              <button
                className="p-2"
                onPointerDown={async () => {
                  try {
                    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                    const r = new MediaRecorder(stream);
                    chunks.current = [];
                    r.ondataavailable = (ev) => chunks.current.push(ev.data);
                    r.onstop = async () => {
                      stream.getTracks().forEach((t) => t.stop());
                      const blob = new Blob(chunks.current, { type: r.mimeType || "audio/webm" });
                      const reader = new FileReader();
                      reader.onload = () => {
                        void send({
                          type: "voice",
                          content: "پیام صوتی",
                          attachment: String(reader.result),
                          mimeType: blob.type,
                          fileName: "voice.webm",
                        });
                      };
                      reader.readAsDataURL(blob);
                    };
                    rec.current = r;
                    r.start();
                  } catch {
                    /* mic denied */
                  }
                }}
                onPointerUp={() => rec.current?.state === "recording" && rec.current.stop()}
              >
                <Icon name="mic" />
              </button>
            )}
          </div>
        </div>
      ) : (
        <p className="p-3 text-center text-sm text-[color:var(--muted)]">فقط مدیران کانال می‌توانند پست بگذارند</p>
      )}

      <Modal open={Boolean(menu)} onClose={() => setMenu(null)} title="پیام">
        {menu ? (
          <div className="grid grid-cols-2 gap-2 text-sm">
            <button className="rounded-2xl bg-white/5 p-3" onClick={() => { void navigator.clipboard.writeText(menu.content); setMenu(null); }}>کپی</button>
            <button className="rounded-2xl bg-white/5 p-3" onClick={() => { setReply(menu); setMenu(null); }}>پاسخ</button>
            <button className="rounded-2xl bg-white/5 p-3" onClick={() => { setForwardOpen(true); void api<{ conversations: Conversation[] }>("conversations").then((d) => setConvs(d.conversations)); }}>ارسال به</button>
            {menu.senderId === me.id && menu.type === "text" ? (
              <button className="rounded-2xl bg-white/5 p-3" onClick={() => { setEditId(menu.id); setText(menu.content); setMenu(null); }}>ویرایش</button>
            ) : null}
            <button className="rounded-2xl bg-white/5 p-3" onClick={async () => { await api(`messages/${menu.id}/react`, { method: "POST", body: JSON.stringify({ emoji: "❤️" }) }); setMenu(null); await load(); }}>❤️</button>
            {(menu.senderId === me.id || detail?.role === "owner" || detail?.role === "admin") ? (
              <button className="rounded-2xl bg-white/5 p-3 text-[#ff6b8a]" onClick={async () => { await api(`messages/${menu.id}`, { method: "DELETE" }); setMenu(null); await load(); }}>حذف</button>
            ) : null}
          </div>
        ) : null}
      </Modal>

      <Modal open={forwardOpen} onClose={() => setForwardOpen(false)} title="ارسال به">
        {convs.map((c) => (
          <button
            key={c.id}
            className="mb-2 block w-full rounded-2xl bg-white/5 p-3 text-right"
            onClick={async () => {
              if (menu) await api(`messages/${menu.id}/forward`, { method: "POST", body: JSON.stringify({ conversationId: c.id }) });
              setForwardOpen(false);
              setMenu(null);
            }}
          >
            {c.title}
          </button>
        ))}
      </Modal>

      <Modal open={info} onClose={() => setInfo(false)} title={title}>
        <p className="text-sm text-[color:var(--muted)]">{detail?.description}</p>
        {detail?.type !== "direct" ? (
          <div className="mt-3 space-y-2">
            {detail?.members.map((m) => (
              <div key={m.userId} className="flex items-center justify-between rounded-2xl bg-white/5 p-2">
                <span>{m.displayName}</span>
                <span className="text-xs text-[color:var(--muted)]">{m.role}</span>
              </div>
            ))}
            {(detail?.role === "owner" || detail?.role === "admin") && (
              <AddMember conversationId={conversationId} onDone={() => void load()} />
            )}
            <button
              className="mt-2 w-full rounded-2xl border border-white/10 py-2 text-sm"
              onClick={async () => {
                await api(`conversations/${conversationId}`, { method: "DELETE" });
                setInfo(false);
                onBack();
                onReloadList();
              }}
            >
              ترک / حذف
            </button>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}

function AddMember({ conversationId, onDone }: { conversationId: string; onDone: () => void }) {
  const [username, setUsername] = useState("");
  return (
    <div className="flex gap-2">
      <input className="field ltr" placeholder="@username" value={username} onChange={(e) => setUsername(e.target.value)} />
      <button
        className="chip"
        onClick={async () => {
          await api(`conversations/${conversationId}/members`, {
            method: "POST",
            body: JSON.stringify({ username: username.replace(/^@/, "") }),
          });
          setUsername("");
          onDone();
        }}
      >
        افزودن
      </button>
    </div>
  );
}

function NewConversation({ onCreated, onClose }: { onCreated: (id: string) => void; onClose: () => void }) {
  const [mode, setMode] = useState<"direct" | "group" | "channel">("direct");
  const [username, setUsername] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  async function create() {
    setErr("");
    setLoading(true);
    try {
      if (mode === "direct") {
        const d = await api<{ conversation: { id: string } }>("conversations", {
          method: "POST",
          body: JSON.stringify({ type: "direct", username: username.replace(/^@/, "") }),
        });
        onCreated(d.conversation.id);
        return;
      }
      const d = await api<{ conversation: { id: string } }>("conversations", {
        method: "POST",
        body: JSON.stringify({ type: mode, title, description }),
      });
      onCreated(d.conversation.id);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "خطا");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="scroll-y h-full px-4 py-4">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="text-xl font-bold">جدید</h2>
        <button onClick={onClose}>
          <Icon name="close" />
        </button>
      </div>
      <div className="mb-4 flex gap-2">
        {(["direct", "group", "channel"] as const).map((m) => (
          <button key={m} className={`chip ${mode === m ? "bg-white/15 text-white" : ""}`} onClick={() => setMode(m)}>
            {m === "direct" ? "چت" : m === "group" ? "گروه" : "کانال"}
          </button>
        ))}
      </div>
      {mode === "direct" ? (
        <input className="field ltr" placeholder="@username" value={username} onChange={(e) => setUsername(e.target.value)} />
      ) : (
        <>
          <input className="field mb-3" placeholder="نام" value={title} onChange={(e) => setTitle(e.target.value)} />
          <textarea className="field min-h-24" placeholder="توضیح" value={description} onChange={(e) => setDescription(e.target.value)} />
        </>
      )}
      {err ? <p className="mt-2 text-sm text-[#ff6b8a]">{err}</p> : null}
      <button className="btn-primary mt-4 flex w-full items-center justify-center gap-2" onClick={() => void create()} disabled={loading}>
        {loading ? <Spinner /> : null}
        ساخت
      </button>
    </div>
  );
}

type BeforeInstallPromptEvent = Event & { prompt: () => Promise<void> };
