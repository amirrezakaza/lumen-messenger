"use client";

import { colorFrom, initials } from "@/lib/client";
import type { CSSProperties, ReactNode } from "react";

export function LumenMark({ size = 44 }: { size?: number }) {
  return (
    <img
      src="/brand/lumen-mark.png"
      alt="Lumen"
      width={size}
      height={size}
      className="rounded-[18px] object-cover shadow-[0_8px_30px_rgba(91,80,220,0.35)]"
      style={{ width: size, height: size }}
    />
  );
}

export function Avatar({
  name,
  src,
  size = 44,
  online,
}: {
  name: string;
  src?: string | null;
  size?: number;
  online?: boolean;
}) {
  const bg = colorFrom(name || "lumen");
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      {src ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={src}
          alt={name}
          className="h-full w-full rounded-2xl object-cover"
        />
      ) : (
        <div
          className="grid h-full w-full place-items-center rounded-2xl text-sm font-bold text-white"
          style={{ background: `linear-gradient(135deg, ${bg}, #1b1e2c)` }}
        >
          {initials(name)}
        </div>
      )}
      {online ? (
        <span className="online-dot absolute -bottom-0.5 -left-0.5 h-3 w-3 rounded-full border-2 border-[#07080f] bg-[#5eead4]" />
      ) : null}
    </div>
  );
}

export function Icon({
  name,
  size = 22,
}: {
  name:
    | "chats"
    | "games"
    | "friends"
    | "user"
    | "search"
    | "plus"
    | "send"
    | "back"
    | "more"
    | "pin"
    | "mute"
    | "bell"
    | "image"
    | "mic"
    | "emoji"
    | "close"
    | "check"
    | "settings"
    | "logout"
    | "coin";
  size?: number;
}) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  switch (name) {
    case "chats":
      return (
        <svg {...common}>
          <path d="M21 12a8.5 8.5 0 0 1-8.5 8.5H7l-4 3V12A8.5 8.5 0 1 1 21 12Z" />
        </svg>
      );
    case "games":
      return (
        <svg {...common}>
          <rect x="3" y="7" width="18" height="12" rx="4" />
          <path d="M8 13h4M10 11v4M16.5 12h.01M18.5 14h.01" />
        </svg>
      );
    case "friends":
      return (
        <svg {...common}>
          <circle cx="9" cy="8" r="3" />
          <path d="M3.5 19a5.5 5.5 0 0 1 11 0" />
          <circle cx="17" cy="9" r="2.4" />
          <path d="M16 19a4.5 4.5 0 0 1 5-4.2" />
        </svg>
      );
    case "user":
      return (
        <svg {...common}>
          <circle cx="12" cy="8" r="3.2" />
          <path d="M5 19a7 7 0 0 1 14 0" />
        </svg>
      );
    case "search":
      return (
        <svg {...common}>
          <circle cx="11" cy="11" r="6.5" />
          <path d="m20 20-3.4-3.4" />
        </svg>
      );
    case "plus":
      return (
        <svg {...common}>
          <path d="M12 5v14M5 12h14" />
        </svg>
      );
    case "send":
      return (
        <svg {...common}>
          <path d="m5 12 14-7-4 14-3-5-7-2Z" />
        </svg>
      );
    case "back":
      return (
        <svg {...common}>
          <path d="M9 6l6 6-6 6" />
        </svg>
      );
    case "more":
      return (
        <svg {...common}>
          <circle cx="6" cy="12" r="1.2" fill="currentColor" />
          <circle cx="12" cy="12" r="1.2" fill="currentColor" />
          <circle cx="18" cy="12" r="1.2" fill="currentColor" />
        </svg>
      );
    case "pin":
      return (
        <svg {...common}>
          <path d="M12 17v5M8 3h8l-1 7a4 4 0 1 1-6 0L8 3Z" />
        </svg>
      );
    case "mute":
      return (
        <svg {...common}>
          <path d="M4 10v4h4l5 4V6L8 10H4Z" />
          <path d="m18 10 4 4M22 10l-4 4" />
        </svg>
      );
    case "bell":
      return (
        <svg {...common}>
          <path d="M6 9a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8" />
          <path d="M10 20a2 2 0 0 0 4 0" />
        </svg>
      );
    case "image":
      return (
        <svg {...common}>
          <rect x="3" y="5" width="18" height="14" rx="3" />
          <circle cx="9" cy="10" r="1.4" />
          <path d="m21 15-5-4-8 8" />
        </svg>
      );
    case "mic":
      return (
        <svg {...common}>
          <rect x="9" y="3" width="6" height="11" rx="3" />
          <path d="M6 12a6 6 0 0 0 12 0M12 18v3" />
        </svg>
      );
    case "emoji":
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="9" />
          <path d="M8 14s1.5 2 4 2 4-2 4-2M9 10h.01M15 10h.01" />
        </svg>
      );
    case "close":
      return (
        <svg {...common}>
          <path d="M6 6l12 12M18 6 6 18" />
        </svg>
      );
    case "check":
      return (
        <svg {...common}>
          <path d="m5 12 5 5 9-10" />
        </svg>
      );
    case "settings":
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="3" />
          <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9c.3.7.9 1.2 1.6 1.3H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z" />
        </svg>
      );
    case "logout":
      return (
        <svg {...common}>
          <path d="M10 7V5a2 2 0 0 1 2-2h7v18h-7a2 2 0 0 1-2-2v-2M3 12h11M6 9l-3 3 3 3" />
        </svg>
      );
    case "coin":
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="8.5" />
          <path d="M12 8v8M9.5 10.5c.5-1 4.5-1 5 1s-4 1.2-4 2.5 4 1 5 0" />
        </svg>
      );
  }
}

export function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-end sm:place-items-center p-0 sm:p-6">
      <button className="absolute inset-0 bg-black/55" onClick={onClose} aria-label="بستن" />
      <div className="glass relative z-10 w-full max-w-md rounded-t-3xl sm:rounded-3xl p-5 max-h-[86dvh] overflow-y-auto">
        <div className="mb-4 flex items-center justify-between gap-3">
          <h3 className="text-lg font-bold">{title}</h3>
          <button onClick={onClose} className="rounded-full p-2 text-[color:var(--muted)]">
            <Icon name="close" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Empty({ title, hint }: { title: string; hint: string }) {
  return (
    <div className="grid place-items-center px-8 py-16 text-center">
      <div className="mb-3 h-16 w-16 rounded-3xl bg-white/5" />
      <p className="font-bold">{title}</p>
      <p className="mt-1 text-sm text-[color:var(--muted)]">{hint}</p>
    </div>
  );
}

export function Spinner({ style }: { style?: CSSProperties }) {
  return (
    <span
      className="inline-block h-5 w-5 animate-spin rounded-full border-2 border-white/20 border-t-white"
      style={style}
    />
  );
}
