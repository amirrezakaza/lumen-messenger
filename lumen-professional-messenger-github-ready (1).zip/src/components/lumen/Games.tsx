"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api, type Me, type PublicUser } from "@/lib/client";
import { Avatar, Icon, Modal } from "./ui";

type GameSlug = "tictactoe" | "rps" | "2048" | "memory" | "snake" | "flappy";

const GAMES: { slug: GameSlug; title: string; hint: string; emoji: string; mp?: boolean }[] = [
  { slug: "tictactoe", title: "دوز", hint: "کلاسیک سه‌تایی", emoji: "✕○", mp: true },
  { slug: "rps", title: "سنگ کاغذ قیچی", hint: "یک حرکت، یک لحظه", emoji: "✊", mp: true },
  { slug: "2048", title: "۲۰۴۸", hint: "ادغام کاشی‌ها", emoji: "🧩" },
  { slug: "memory", title: "کارت حافظه", hint: "جفت‌ها را پیدا کن", emoji: "🃏" },
  { slug: "snake", title: "مار", hint: "با انگشت هدایت کن", emoji: "🐍" },
  { slug: "flappy", title: "پرواز لومن", hint: "ضربه برای اوج", emoji: "✦" },
];

type Match = {
  id: string;
  gameType: string;
  status: string;
  player1Id: string;
  player2Id: string;
  turnUserId: string | null;
  winnerId: string | null;
  state: Record<string, unknown>;
  player1?: PublicUser;
  player2?: PublicUser;
};

export function GamesHub({
  me,
  onCoins,
  onBack,
}: {
  me: Me;
  onCoins: (n: number, stats?: Me["stats"]) => void;
  onBack?: () => void;
}) {
  const [slug, setSlug] = useState<GameSlug | null>(null);
  const [matchId, setMatchId] = useState<string | null>(null);
  const [friendsOpen, setFriendsOpen] = useState(false);
  const [inviteGame, setInviteGame] = useState<GameSlug | null>(null);
  const [friends, setFriends] = useState<{ id: string; user?: PublicUser }[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [board, setBoard] = useState<{ leaderboard: { userId: string; displayName: string; username: string; xp: number; level: number; wins: number }[] } | null>(null);

  const reload = useCallback(() => {
    void api<{ matches: Match[] }>("games/matches").then((d) => setMatches(d.matches));
    void api<{ leaderboard: { userId: string; displayName: string; username: string; xp: number; level: number; wins: number }[] }>("games/leaderboard").then(setBoard);
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  async function invite(userId: string) {
    if (!inviteGame) return;
    const data = await api<{ match: Match }>("games/matches", {
      method: "POST",
      body: JSON.stringify({ gameType: inviteGame, opponentId: userId }),
    });
    setFriendsOpen(false);
    setMatchId(data.match.id);
    setSlug(inviteGame);
  }

  if (slug) {
    return (
      <GameScreen
        me={me}
        slug={slug}
        matchId={matchId}
        onBack={() => {
          setSlug(null);
          setMatchId(null);
          reload();
        }}
        onCoins={onCoins}
      />
    );
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="flex items-center justify-between gap-3 px-4 py-3">
        {onBack ? (
          <button onClick={onBack} className="lg:hidden">
            <Icon name="back" />
          </button>
        ) : (
          <span />
        )}
        <div>
          <p className="text-[11px] tracking-[0.25em] text-[color:var(--gold)]">LUMEN GAMES</p>
          <h2 className="text-xl font-bold">زمین بازی</h2>
        </div>
        <div className="chip">
          <Icon name="coin" size={14} /> {me.coins}
        </div>
      </header>
      <div className="scroll-y min-h-0 flex-1 px-4 pb-28">
        <div className="grid grid-cols-2 gap-3">
          {GAMES.map((g) => (
            <button
              key={g.slug}
              onClick={() => setSlug(g.slug)}
              className="glass rounded-3xl p-4 text-right"
            >
              <div className="text-2xl">{g.emoji}</div>
              <div className="mt-3 font-bold">{g.title}</div>
              <div className="mt-1 text-xs text-[color:var(--muted)]">{g.hint}</div>
              {g.mp ? (
                <div
                  className="mt-3 text-xs text-[color:var(--accent-2)]"
                  onClick={(e) => {
                    e.stopPropagation();
                    setInviteGame(g.slug);
                    void api<{ friends: { id: string; user?: PublicUser }[] }>("friends").then((d) => {
                      setFriends(d.friends);
                      setFriendsOpen(true);
                    });
                  }}
                >
                  دعوت دوست →
                </div>
              ) : null}
            </button>
          ))}
        </div>

        <h3 className="mt-8 mb-3 font-bold">مسابقه‌های زنده</h3>
        {matches.length === 0 ? (
          <p className="text-sm text-[color:var(--muted)]">هنوز دعوتی نیست.</p>
        ) : (
          <div className="space-y-2">
            {matches.slice(0, 8).map((m) => {
              const other = m.player1Id === me.id ? m.player2 : m.player1;
              return (
                <button
                  key={m.id}
                  className="glass flex w-full items-center gap-3 rounded-2xl p-3 text-right"
                  onClick={() => {
                    setSlug(m.gameType as GameSlug);
                    setMatchId(m.id);
                  }}
                >
                  <Avatar name={other?.displayName || "?"} src={other?.avatarUrl} size={40} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-semibold">{other?.displayName}</div>
                    <div className="text-xs text-[color:var(--muted)]">
                      {m.gameType} · {m.status === "pending" ? "در انتظار" : m.status === "active" ? "در حال بازی" : m.status === "finished" ? "تمام" : "رد شد"}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}

        <h3 className="mt-8 mb-3 font-bold">جدول امتیاز</h3>
        <div className="space-y-2">
          {(board?.leaderboard ?? []).map((row, i) => (
            <div key={row.userId} className="flex items-center gap-3 rounded-2xl bg-white/5 px-3 py-2">
              <span className="w-6 text-[color:var(--gold)]">{i + 1}</span>
              <div className="min-w-0 flex-1">
                <div className="truncate font-semibold">{row.displayName}</div>
                <div className="ltr text-xs text-[color:var(--muted)]">@{row.username}</div>
              </div>
              <div className="text-xs">Lv {row.level} · {row.xp} XP</div>
            </div>
          ))}
        </div>
      </div>

      <Modal open={friendsOpen} onClose={() => setFriendsOpen(false)} title="دعوت به بازی">
        {friends.map((f) =>
          f.user ? (
            <button
              key={f.id}
              className="mb-2 flex w-full items-center gap-3 rounded-2xl bg-white/5 p-3"
              onClick={() => invite(f.user!.id)}
            >
              <Avatar name={f.user.displayName} src={f.user.avatarUrl} size={40} online={f.user.isOnline} />
              <span>{f.user.displayName}</span>
            </button>
          ) : null,
        )}
        {!friends.length ? <p className="text-sm text-[color:var(--muted)]">اول دوست اضافه کنید.</p> : null}
      </Modal>
    </div>
  );
}

function GameScreen({
  me,
  slug,
  matchId,
  onBack,
  onCoins,
}: {
  me: Me;
  slug: GameSlug;
  matchId: string | null;
  onBack: () => void;
  onCoins: (n: number, stats?: Me["stats"]) => void;
}) {
  const title = GAMES.find((g) => g.slug === slug)?.title ?? slug;
  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="flex items-center gap-3 px-4 py-3">
        <button onClick={onBack}>
          <Icon name="back" />
        </button>
        <h2 className="font-bold">{title}</h2>
      </header>
      <div className="min-h-0 flex-1 overflow-hidden px-3 pb-6">
        {slug === "tictactoe" ? (
          <TicTacToe me={me} matchId={matchId} onCoins={onCoins} />
        ) : slug === "rps" ? (
          <RPS me={me} matchId={matchId} onCoins={onCoins} />
        ) : slug === "2048" ? (
          <Game2048 onCoins={onCoins} />
        ) : slug === "memory" ? (
          <Memory onCoins={onCoins} />
        ) : slug === "snake" ? (
          <Snake onCoins={onCoins} />
        ) : (
          <Flappy onCoins={onCoins} />
        )}
      </div>
    </div>
  );
}

async function report(gameType: string, result: "win" | "loss" | "draw", onCoins: (n: number, stats?: Me["stats"]) => void) {
  try {
    const data = await api<{ coins: number; stats: Me["stats"] }>("games/solo", {
      method: "POST",
      body: JSON.stringify({ gameType, result }),
    });
    onCoins(data.coins, data.stats);
  } catch {
    /* ignore */
  }
}

function TicTacToe({
  me,
  matchId,
  onCoins,
}: {
  me: Me;
  matchId: string | null;
  onCoins: (n: number, stats?: Me["stats"]) => void;
}) {
  const [board, setBoard] = useState<string[]>(Array(9).fill(""));
  const [turn, setTurn] = useState<"X" | "O">("X");
  const [done, setDone] = useState("");
  const [match, setMatch] = useState<Match | null>(null);
  const mark = match ? (match.state.x === me.id ? "X" : "O") : "X";

  useEffect(() => {
    if (!matchId) return;
    let live = true;
    const load = () =>
      api<{ match: Match }>(`games/matches/${matchId}`).then((d) => {
        if (!live) return;
        setMatch(d.match);
        setBoard((d.match.state.board as string[]) ?? Array(9).fill(""));
      });
    void load();
    const t = setInterval(load, 1200);
    return () => {
      live = false;
      clearInterval(t);
    };
  }, [matchId]);

  function winner(b: string[]) {
    const L = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];
    for (const [a, c, d] of L) if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a];
    if (b.every(Boolean)) return "draw";
    return "";
  }

  async function play(i: number) {
    if (board[i] || done) return;
    if (matchId && match) {
      if (match.status === "pending") {
        if (match.player2Id === me.id) {
          await api(`games/matches/${matchId}/accept`, { method: "POST", body: "{}" });
        } else return;
      }
      if (match.turnUserId && match.turnUserId !== me.id) return;
      await api(`games/matches/${matchId}/move`, { method: "POST", body: JSON.stringify({ index: i }) });
      const d = await api<{ match: Match }>(`games/matches/${matchId}`);
      setMatch(d.match);
      setBoard((d.match.state.board as string[]) ?? []);
      return;
    }
    const next = board.slice();
    next[i] = turn;
    const w = winner(next);
    if (w) {
      setBoard(next);
      setDone(w === "draw" ? "مساوی" : w === "X" ? "بردید" : "باختید");
      void report("tictactoe", w === "draw" ? "draw" : w === "X" ? "win" : "loss", onCoins);
      return;
    }
    const empty = next.map((v, idx) => (v ? -1 : idx)).filter((v) => v >= 0);
    const ai = empty[Math.floor(Math.random() * empty.length)];
    next[ai] = "O";
    const w2 = winner(next);
    setBoard(next);
    setTurn("X");
    if (w2) {
      setDone(w2 === "draw" ? "مساوی" : w2 === "X" ? "بردید" : "باختید");
      void report("tictactoe", w2 === "draw" ? "draw" : w2 === "X" ? "win" : "loss", onCoins);
    }
  }

  return (
    <div className="mx-auto max-w-sm">
      {match?.status === "pending" ? (
        <p className="mb-3 text-center text-sm text-[color:var(--gold)]">
          {match.player2Id === me.id ? "دعوت را با اولین حرکت بپذیرید" : "منتظر پذیرش دوست"}
        </p>
      ) : null}
      <div className="grid grid-cols-3 gap-2">
        {board.map((c, i) => (
          <button
            key={i}
            onClick={() => play(i)}
            className="aspect-square rounded-3xl bg-white/5 text-3xl font-bold"
          >
            {c}
          </button>
        ))}
      </div>
      <p className="mt-4 text-center text-sm text-[color:var(--muted)]">
        {done || (match ? `شما ${mark}` : "شما X هستید")}
      </p>
    </div>
  );
}

function RPS({
  me,
  matchId,
  onCoins,
}: {
  me: Me;
  matchId: string | null;
  onCoins: (n: number, stats?: Me["stats"]) => void;
}) {
  const [mine, setMine] = useState("");
  const [result, setResult] = useState("");
  const [match, setMatch] = useState<Match | null>(null);
  const moves = [
    { id: "rock", label: "سنگ" },
    { id: "paper", label: "کاغذ" },
    { id: "scissors", label: "قیچی" },
  ];

  useEffect(() => {
    if (!matchId) return;
    const load = () =>
      api<{ match: Match }>(`games/matches/${matchId}`).then((d) => setMatch(d.match));
    void load();
    const t = setInterval(load, 1200);
    return () => clearInterval(t);
  }, [matchId]);

  async function pick(id: string) {
    setMine(id);
    if (matchId) {
      if (match?.status === "pending" && match.player2Id === me.id) {
        await api(`games/matches/${matchId}/accept`, { method: "POST", body: "{}" });
      }
      await api(`games/matches/${matchId}/move`, { method: "POST", body: JSON.stringify({ move: id }) });
      return;
    }
    const cpu = moves[Math.floor(Math.random() * 3)].id;
    const win =
      id === cpu ? "draw" : (id === "rock" && cpu === "scissors") || (id === "paper" && cpu === "rock") || (id === "scissors" && cpu === "paper") ? "win" : "loss";
    setResult(win === "draw" ? `مساوی با ${cpu}` : win === "win" ? `بردید مقابل ${cpu}` : `باختید مقابل ${cpu}`);
    void report("rps", win, onCoins);
  }

  return (
    <div className="mx-auto max-w-sm text-center">
      <div className="grid grid-cols-3 gap-2">
        {moves.map((m) => (
          <button key={m.id} onClick={() => pick(m.id)} className="glass rounded-3xl py-8 font-bold">
            {m.label}
          </button>
        ))}
      </div>
      <p className="mt-4 text-sm text-[color:var(--muted)]">{result || (mine ? "انتخاب شد" : "انتخاب کنید")}</p>
      {match?.status === "finished" ? (
        <p className="mt-2 text-[color:var(--gold)]">
          {match.winnerId === "draw" ? "مساوی" : match.winnerId === me.id ? "بردید" : "باختید"}
        </p>
      ) : null}
    </div>
  );
}

function Game2048({ onCoins }: { onCoins: (n: number, stats?: Me["stats"]) => void }) {
  const empty = () =>
    Array.from({ length: 16 }, () => 0);
  const spawn = (b: number[]) => {
    const n = b.slice();
    const zs = n.map((v, i) => (v === 0 ? i : -1)).filter((i) => i >= 0);
    if (!zs.length) return n;
    n[zs[Math.floor(Math.random() * zs.length)]] = Math.random() < 0.9 ? 2 : 4;
    return n;
  };
  const [board, setBoard] = useState<number[]>(() => spawn(spawn(empty())));
  const [score, setScore] = useState(0);
  const [sent, setSent] = useState(false);
  const start = useRef<{ x: number; y: number } | null>(null);

  const slide = (row: number[]) => {
    const a = row.filter(Boolean);
    let s = 0;
    for (let i = 0; i < a.length - 1; i++) {
      if (a[i] === a[i + 1]) {
        a[i] *= 2;
        s += a[i];
        a[i + 1] = 0;
      }
    }
    const b = a.filter(Boolean);
    while (b.length < 4) b.push(0);
    return { row: b, s };
  };

  const move = (dir: "l" | "r" | "u" | "d") => {
    const g = board.slice();
    let gained = 0;
    const take = (i: number, j: number) => g[i * 4 + j];
    const put = (i: number, j: number, v: number) => {
      g[i * 4 + j] = v;
    };
    for (let i = 0; i < 4; i++) {
      let row: number[] = [];
      for (let j = 0; j < 4; j++) {
        if (dir === "l") row.push(take(i, j));
        if (dir === "r") row.push(take(i, 3 - j));
        if (dir === "u") row.push(take(j, i));
        if (dir === "d") row.push(take(3 - j, i));
      }
      const res = slide(row);
      gained += res.s;
      for (let j = 0; j < 4; j++) {
        const v = res.row[j];
        if (dir === "l") put(i, j, v);
        if (dir === "r") put(i, 3 - j, v);
        if (dir === "u") put(j, i, v);
        if (dir === "d") put(3 - j, i, v);
      }
    }
    if (g.join() === board.join()) return;
    const next = spawn(g);
    setBoard(next);
    setScore((x) => x + gained);
    if (!sent && next.some((v) => v >= 2048)) {
      setSent(true);
      void report("2048", "win", onCoins);
    }
  };

  return (
    <div
      className="mx-auto max-w-sm touch-none"
      onTouchStart={(e) => {
        start.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }}
      onTouchEnd={(e) => {
        if (!start.current) return;
        const dx = e.changedTouches[0].clientX - start.current.x;
        const dy = e.changedTouches[0].clientY - start.current.y;
        if (Math.abs(dx) + Math.abs(dy) < 24) return;
        if (Math.abs(dx) > Math.abs(dy)) move(dx > 0 ? "r" : "l");
        else move(dy > 0 ? "d" : "u");
      }}
    >
      <p className="mb-3 text-center">امتیاز {score}</p>
      <div className="grid grid-cols-4 gap-2">
        {board.map((n, i) => (
          <div
            key={i}
            className="grid aspect-square place-items-center rounded-2xl text-lg font-bold"
            style={{ background: n ? `hsla(${40 + Math.log2(n) * 18},80%,55%,0.85)` : "rgba(255,255,255,0.04)" }}
          >
            {n || ""}
          </div>
        ))}
      </div>
      <p className="mt-3 text-center text-xs text-[color:var(--muted)]">سوایپ کنید</p>
    </div>
  );
}

function Memory({ onCoins }: { onCoins: (n: number, stats?: Me["stats"]) => void }) {
  const emojis = ["🌙", "✦", "🎧", "🍀", "🔥", "💎", "🌊", "🦋"];
  const shuffle = () =>
    [...emojis, ...emojis]
      .map((e, i) => ({ e, i, s: Math.random() }))
      .sort((a, b) => a.s - b.s)
      .map((x, i) => ({ id: i, e: x.e, open: false, done: false }));
  const [cards, setCards] = useState(shuffle);
  const [picked, setPicked] = useState<number[]>([]);
  const [lock, setLock] = useState(false);

  function flip(i: number) {
    if (lock || cards[i].open || cards[i].done) return;
    const next = cards.map((c, idx) => (idx === i ? { ...c, open: true } : c));
    const p = [...picked, i];
    setCards(next);
    setPicked(p);
    if (p.length === 2) {
      setLock(true);
      setTimeout(() => {
        setCards((cur) => {
          const a = cur[p[0]];
          const b = cur[p[1]];
          if (a.e === b.e) {
            const done = cur.map((c, idx) => (idx === p[0] || idx === p[1] ? { ...c, done: true } : c));
            if (done.every((c) => c.done)) void report("memory", "win", onCoins);
            return done;
          }
          return cur.map((c, idx) => (idx === p[0] || idx === p[1] ? { ...c, open: false } : c));
        });
        setPicked([]);
        setLock(false);
      }, 650);
    }
  }

  return (
    <div className="mx-auto grid max-w-sm grid-cols-4 gap-2">
      {cards.map((c, i) => (
        <button
          key={c.id}
          onClick={() => flip(i)}
          className="aspect-square rounded-2xl bg-white/5 text-2xl"
        >
          {c.open || c.done ? c.e : "•"}
        </button>
      ))}
    </div>
  );
}

function Snake({ onCoins }: { onCoins: (n: number, stats?: Me["stats"]) => void }) {
  const canvas = useRef<HTMLCanvasElement | null>(null);
  const dir = useRef({ x: 1, y: 0 });
  const reported = useRef(false);

  useEffect(() => {
    const c = canvas.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    const cell = 16;
    let snake = [{ x: 8, y: 8 }];
    let food = { x: 12, y: 10 };
    let alive = true;
    const tick = setInterval(() => {
      if (!alive) return;
      const head = { x: snake[0].x + dir.current.x, y: snake[0].y + dir.current.y };
      if (head.x < 0 || head.y < 0 || head.x > 19 || head.y > 19 || snake.some((s) => s.x === head.x && s.y === head.y)) {
        alive = false;
        if (!reported.current) {
          reported.current = true;
          void report("snake", snake.length > 8 ? "win" : "loss", onCoins);
        }
        return;
      }
      snake = [head, ...snake];
      if (head.x === food.x && head.y === food.y) {
        food = { x: Math.floor(Math.random() * 20), y: Math.floor(Math.random() * 20) };
      } else snake.pop();
      ctx.fillStyle = "#0c0e16";
      ctx.fillRect(0, 0, 320, 320);
      ctx.fillStyle = "#e4c078";
      ctx.fillRect(food.x * cell, food.y * cell, cell - 2, cell - 2);
      ctx.fillStyle = "#8b7cff";
      snake.forEach((s) => ctx.fillRect(s.x * cell, s.y * cell, cell - 2, cell - 2));
    }, 140);
    return () => clearInterval(tick);
  }, [onCoins]);

  function swipe(dx: number, dy: number) {
    if (Math.abs(dx) > Math.abs(dy)) dir.current = { x: dx > 0 ? 1 : -1, y: 0 };
    else dir.current = { x: 0, y: dy > 0 ? 1 : -1 };
  }
  const start = useRef<{ x: number; y: number } | null>(null);

  return (
    <canvas
      ref={canvas}
      width={320}
      height={320}
      className="mx-auto block w-full max-w-[320px] rounded-3xl bg-black touch-none"
      onTouchStart={(e) => {
        start.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }}
      onTouchEnd={(e) => {
        if (!start.current) return;
        swipe(e.changedTouches[0].clientX - start.current.x, e.changedTouches[0].clientY - start.current.y);
      }}
    />
  );
}

function Flappy({ onCoins }: { onCoins: (n: number, stats?: Me["stats"]) => void }) {
  const canvas = useRef<HTMLCanvasElement | null>(null);
  const reported = useRef(false);

  useEffect(() => {
    const c = canvas.current;
    if (!c) return;
    const ctx = c.getContext("2d");
    if (!ctx) return;
    let y = 140;
    let vy = 0;
    let x = 0;
    let alive = true;
    let score = 0;
    const pipes = [
      { x: 280, h: 90 },
      { x: 460, h: 130 },
    ];
    const loop = () => {
      vy += 0.35;
      y += vy;
      x += 1;
      ctx.fillStyle = "#0b0d16";
      ctx.fillRect(0, 0, 320, 320);
      ctx.fillStyle = "#4ee1ff";
      pipes.forEach((p) => {
        p.x -= 2.2;
        if (p.x < -40) {
          p.x = 340;
          p.h = 60 + Math.random() * 120;
          score += 1;
        }
        ctx.fillRect(p.x, 0, 36, p.h);
        ctx.fillRect(p.x, p.h + 90, 36, 320);
        if (40 < p.x + 36 && 40 + 18 > p.x && (y < p.h || y + 18 > p.h + 90)) alive = false;
      });
      ctx.fillStyle = "#e4c078";
      ctx.beginPath();
      ctx.arc(48, y, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.fillText(String(score), 12, 24);
      if (y > 320 || y < 0) alive = false;
      if (!alive) {
        if (!reported.current) {
          reported.current = true;
          void report("flappy", score >= 5 ? "win" : "loss", onCoins);
        }
        ctx.fillStyle = "rgba(0,0,0,0.4)";
        ctx.fillRect(0, 0, 320, 320);
        return;
      }
      requestAnimationFrame(loop);
    };
    const flap = () => {
      if (!alive) return;
      vy = -6.2;
    };
    c.addEventListener("pointerdown", flap);
    requestAnimationFrame(loop);
    return () => c.removeEventListener("pointerdown", flap);
  }, [onCoins]);

  return (
    <canvas
      ref={canvas}
      width={320}
      height={320}
      className="mx-auto block w-full max-w-[320px] rounded-3xl bg-black"
    />
  );
}
