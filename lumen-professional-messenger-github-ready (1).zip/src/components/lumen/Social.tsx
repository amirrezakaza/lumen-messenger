"use client";

import { useEffect, useState } from "react";
import { api, fileToDataUrl, timeAgo, type Me, type Privacy, type PublicUser } from "@/lib/client";
import { Avatar, Empty, Icon, Modal, Spinner } from "./ui";

export function FriendsView({
  onOpenUser,
  onMessage,
}: {
  onOpenUser: (id: string) => void;
  onMessage: (username: string) => void;
}) {
  const [tab, setTab] = useState<"friends" | "in" | "out">("friends");
  const [q, setQ] = useState("");
  const [data, setData] = useState<{
    friends: { id: string; user?: PublicUser }[];
    incoming: { id: string; user?: PublicUser }[];
    outgoing: { id: string; user?: PublicUser }[];
  }>({ friends: [], incoming: [], outgoing: [] });
  const [err, setErr] = useState("");

  async function load() {
    const d = await api<typeof data>("friends");
    setData(d);
  }
  useEffect(() => {
    void load();
  }, []);

  async function add() {
    setErr("");
    try {
      await api("friends", { method: "POST", body: JSON.stringify({ username: q.replace(/^@/, "") }) });
      setQ("");
      await load();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "خطا");
    }
  }

  const list = tab === "friends" ? data.friends : tab === "in" ? data.incoming : data.outgoing;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="px-4 py-3">
        <h2 className="text-xl font-bold">دوستان</h2>
        <div className="mt-3 flex gap-2">
          <input className="field ltr" placeholder="@username" value={q} onChange={(e) => setQ(e.target.value)} />
          <button className="btn-primary shrink-0 px-4" onClick={add}>
            افزودن
          </button>
        </div>
        {err ? <p className="mt-2 text-sm text-[#ff6b8a]">{err}</p> : null}
        <div className="mt-3 flex gap-2 text-sm">
          {(
            [
              ["friends", "دوستان"],
              ["in", "درخواست‌ها"],
              ["out", "ارسال‌شده"],
            ] as const
          ).map(([k, l]) => (
            <button key={k} onClick={() => setTab(k)} className={`chip ${tab === k ? "bg-white/10 text-white" : ""}`}>
              {l}
            </button>
          ))}
        </div>
      </header>
      <div className="scroll-y min-h-0 flex-1 px-4 pb-28">
        {list.length === 0 ? <Empty title="خالی است" hint="با نام کاربری دوست اضافه کنید" /> : null}
        {list.map((row) =>
          row.user ? (
            <div key={row.id} className="mb-2 flex items-center gap-3 rounded-2xl bg-white/5 p-3">
              <button onClick={() => onOpenUser(row.user!.id)}>
                <Avatar name={row.user.displayName} src={row.user.avatarUrl} online={row.user.isOnline} />
              </button>
              <div className="min-w-0 flex-1">
                <div className="truncate font-semibold">{row.user.displayName}</div>
                <div className="ltr text-xs text-[color:var(--muted)]">@{row.user.username}</div>
              </div>
              {tab === "friends" ? (
                <div className="flex gap-2">
                  <button className="chip" onClick={() => onMessage(row.user!.username)}>
                    پیام
                  </button>
                  <button
                    className="chip"
                    onClick={async () => {
                      await api(`friends/${row.id}`, { method: "DELETE" });
                      await load();
                    }}
                  >
                    حذف
                  </button>
                </div>
              ) : null}
              {tab === "in" ? (
                <div className="flex gap-2">
                  <button
                    className="chip"
                    onClick={async () => {
                      await api(`friends/${row.id}/accept`, { method: "POST", body: "{}" });
                      await load();
                    }}
                  >
                    قبول
                  </button>
                  <button
                    className="chip"
                    onClick={async () => {
                      await api(`friends/${row.id}/reject`, { method: "POST", body: "{}" });
                      await load();
                    }}
                  >
                    رد
                  </button>
                </div>
              ) : null}
            </div>
          ) : null,
        )}
      </div>
    </div>
  );
}

export function ProfileView({
  me,
  setMe,
  onLogout,
}: {
  me: Me;
  setMe: (u: Me) => void;
  onLogout: () => void;
}) {
  const [name, setName] = useState(me.displayName);
  const [username, setUsername] = useState(me.username);
  const [bio, setBio] = useState(me.bio);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  async function save() {
    setSaving(true);
    setMsg("");
    try {
      const d = await api<{ user: Me }>("auth/me", {
        method: "PATCH",
        body: JSON.stringify({ displayName: name, username, bio }),
      });
      setMe(d.user);
      setMsg("ذخیره شد");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "خطا");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="scroll-y h-full px-4 py-4 pb-28">
      <div className="flex flex-col items-center text-center">
        <label className="cursor-pointer">
          <Avatar name={me.displayName} src={me.avatarUrl} size={92} />
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              const avatarUrl = await fileToDataUrl(f, 700_000);
              const d = await api<{ user: Me }>("auth/me", { method: "PATCH", body: JSON.stringify({ avatarUrl }) });
              setMe(d.user);
            }}
          />
        </label>
        <p className="mt-3 text-xs text-[color:var(--muted)]">برای تغییر عکس ضربه بزنید</p>
        <div className="mt-3 flex gap-2 text-xs">
          <span className="chip">Lv {me.stats.level}</span>
          <span className="chip">{me.coins} کوین</span>
          <span className="chip">{me.stats.wins} برد</span>
        </div>
      </div>
      <label className="mt-6 block text-xs text-[color:var(--muted)]">نام</label>
      <input className="field mt-1" value={name} onChange={(e) => setName(e.target.value)} />
      <label className="mt-3 block text-xs text-[color:var(--muted)]">نام کاربری</label>
      <input className="field ltr mt-1" value={username} onChange={(e) => setUsername(e.target.value)} />
      <label className="mt-3 block text-xs text-[color:var(--muted)]">بیو</label>
      <textarea className="field mt-1 min-h-24" value={bio} onChange={(e) => setBio(e.target.value)} />
      {msg ? <p className="mt-2 text-sm text-[color:var(--gold)]">{msg}</p> : null}
      <button className="btn-primary mt-4 flex w-full items-center justify-center gap-2" onClick={save} disabled={saving}>
        {saving ? <Spinner /> : null}
        ذخیره پروفایل
      </button>
      <button className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl border border-white/10 py-3" onClick={onLogout}>
        <Icon name="logout" size={18} /> خروج
      </button>
    </div>
  );
}

export function SettingsView({ me, setMe }: { me: Me; setMe: (u: Me) => void }) {
  const vis: Privacy["lastSeen"][] = ["everyone", "friends", "nobody"];
  const labels: Record<string, string> = { everyone: "همه", friends: "دوستان", nobody: "هیچ‌کس" };
  const [privacy, setPrivacy] = useState(me.privacy);

  async function setKey(key: keyof Privacy, value: Privacy["lastSeen"]) {
    const next = { ...privacy, [key]: value };
    setPrivacy(next);
    const d = await api<{ user: Me }>("auth/me", { method: "PATCH", body: JSON.stringify({ privacy: next }) });
    setMe(d.user);
  }

  const rows: { key: keyof Privacy; title: string }[] = [
    { key: "lastSeen", title: "آخرین بازدید" },
    { key: "profilePhoto", title: "عکس پروفایل" },
    { key: "onlineStatus", title: "وضعیت آنلاین" },
    { key: "whoCanMessage", title: "چه کسی می‌تواند پیام بدهد" },
    { key: "whoCanAddToGroups", title: "چه کسی به گروه اضافه‌ام کند" },
  ];

  const shop = [
    { id: "ember", name: " Ember", cost: 200 },
    { id: "forest", name: "Forest", cost: 200 },
    { id: "royal", name: "Royal", cost: 500 },
  ];

  return (
    <div className="scroll-y h-full px-4 py-4 pb-28">
      <h2 className="text-xl font-bold">تنظیمات و حریم خصوصی</h2>
      <p className="mt-1 text-sm text-[color:var(--muted)]">{me.coins} لومن‌کوین</p>
      {rows.map((r) => (
        <div key={r.key} className="mt-5">
          <div className="mb-2 text-sm">{r.title}</div>
          <div className="flex gap-2">
            {vis.map((v) => (
              <button
                key={v}
                className={`chip ${privacy[r.key] === v ? "bg-white/15 text-white" : ""}`}
                onClick={() => setKey(r.key, v)}
              >
                {labels[v]}
              </button>
            ))}
          </div>
        </div>
      ))}

      <h3 className="mt-8 font-bold">تم‌ها با لومن‌کوین</h3>
      <div className="mt-3 space-y-2">
        {[{ id: "aurora", name: "Aurora", cost: 0 }, ...shop].map((t) => {
          const unlocked = me.unlockedThemes.includes(t.id) || t.cost === 0;
          return (
            <div key={t.id} className="glass flex items-center justify-between rounded-2xl p-3">
              <div>
                <div className="font-semibold">{t.name}</div>
                <div className="text-xs text-[color:var(--muted)]">{t.cost ? `${t.cost} کوین` : "پیش‌فرض"}</div>
              </div>
              {unlocked ? (
                <button
                  className="chip"
                  onClick={async () => {
                    const d = await api<{ user: Me }>("auth/me", { method: "PATCH", body: JSON.stringify({ theme: t.id }) });
                    setMe(d.user);
                  }}
                >
                  {me.theme === t.id ? "فعال" : "اعمال"}
                </button>
              ) : (
                <button
                  className="chip"
                  onClick={async () => {
                    const d = await api<{ user: Me }>("coins/spend", { method: "POST", body: JSON.stringify({ item: t.id }) });
                    setMe(d.user);
                  }}
                >
                  خرید
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function SearchView({
  onOpenChat,
  onOpenUser,
}: {
  onOpenChat: (id: string) => void;
  onOpenUser: (id: string) => void;
}) {
  const [q, setQ] = useState("");
  const [res, setRes] = useState<{
    users: PublicUser[];
    conversations: { id: string; type: string; title: string | null; description: string | null }[];
    messages: { id: string; conversationId: string; content: string; createdAt: string }[];
  }>({ users: [], conversations: [], messages: [] });

  useEffect(() => {
    const t = setTimeout(() => {
      if (!q.trim()) return;
      void api<typeof res>(`search?q=${encodeURIComponent(q)}`).then(setRes);
    }, 250);
    return () => clearTimeout(t);
  }, [q]);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="px-4 py-3">
        <input className="field" placeholder="جستجوی افراد، گروه، کانال، پیام" value={q} onChange={(e) => setQ(e.target.value)} />
      </header>
      <div className="scroll-y min-h-0 flex-1 px-4 pb-28">
        <h3 className="mb-2 mt-2 text-sm text-[color:var(--muted)]">کاربران</h3>
        {res.users.map((u) => (
          <button key={u.id} className="mb-2 flex w-full items-center gap-3 rounded-2xl bg-white/5 p-3" onClick={() => onOpenUser(u.id)}>
            <Avatar name={u.displayName} src={u.avatarUrl} online={u.isOnline} />
            <div className="text-right">
              <div className="font-semibold">{u.displayName}</div>
              <div className="ltr text-xs text-[color:var(--muted)]">@{u.username}</div>
            </div>
          </button>
        ))}
        <h3 className="mb-2 mt-4 text-sm text-[color:var(--muted)]">گفتگوها و کانال‌ها</h3>
        {res.conversations.map((c) => (
          <button key={c.id} className="mb-2 block w-full rounded-2xl bg-white/5 p-3 text-right" onClick={() => onOpenChat(c.id)}>
            <div className="font-semibold">{c.title}</div>
            <div className="text-xs text-[color:var(--muted)]">{c.type}</div>
          </button>
        ))}
        <h3 className="mb-2 mt-4 text-sm text-[color:var(--muted)]">پیام‌ها</h3>
        {res.messages.map((m) => (
          <button key={m.id} className="mb-2 block w-full rounded-2xl bg-white/5 p-3 text-right" onClick={() => onOpenChat(m.conversationId)}>
            <div className="line-clamp-2 text-sm">{m.content}</div>
            <div className="text-xs text-[color:var(--muted)]">{timeAgo(m.createdAt)}</div>
          </button>
        ))}
      </div>
    </div>
  );
}

export function NotificationsView() {
  const [rows, setRows] = useState<{ id: string; title: string; body: string; createdAt: string; read: boolean }[]>([]);
  useEffect(() => {
    void api<{ notifications: typeof rows }>("notifications").then((d) => setRows(d.notifications));
    void api("notifications/read", { method: "POST", body: "{}" });
  }, []);
  return (
    <div className="scroll-y h-full px-4 py-4 pb-28">
      <h2 className="mb-4 text-xl font-bold">اعلان‌ها</h2>
      {rows.length === 0 ? <Empty title="اعلانی نیست" hint="پیام‌ها و دعوت‌ها اینجا می‌آیند" /> : null}
      {rows.map((n) => (
        <div key={n.id} className="mb-2 rounded-2xl bg-white/5 p-3">
          <div className="font-semibold">{n.title}</div>
          <div className="text-sm text-[color:var(--muted)]">{n.body}</div>
          <div className="mt-1 text-xs text-[color:var(--muted)]">{timeAgo(n.createdAt)}</div>
        </div>
      ))}
    </div>
  );
}

export function UserModal({
  id,
  onClose,
  onMessage,
}: {
  id: string | null;
  onClose: () => void;
  onMessage: (username: string) => void;
}) {
  const [data, setData] = useState<{
    user: PublicUser & { bio?: string; isFriend?: boolean; stats?: Me["stats"] };
  } | null>(null);
  useEffect(() => {
    if (!id) return;
    void api<{ user: PublicUser & { bio?: string; isFriend?: boolean; stats?: Me["stats"] } }>(`users/${id}`).then(setData);
  }, [id]);
  const u = data?.user;
  return (
    <Modal open={Boolean(id)} onClose={onClose} title="پروفایل">
      {!u ? <Spinner /> : (
        <div className="text-center">
          <div className="flex justify-center">
            <Avatar name={u.displayName} src={u.avatarUrl} size={80} online={u.isOnline} />
          </div>
          <h3 className="mt-3 text-lg font-bold">{u.displayName}</h3>
          <p className="ltr text-sm text-[color:var(--muted)]">@{u.username}</p>
          <p className="mt-2 text-sm">{u.bio}</p>
          <p className="mt-2 text-xs text-[color:var(--muted)]">
            {u.isOnline ? "آنلاین" : u.lastSeen ? `آخرین بازدید ${timeAgo(u.lastSeen)}` : "آخرین بازدید مخفی"}
          </p>
          {u.stats ? (
            <p className="mt-2 text-xs">Lv {u.stats.level} · {u.stats.wins} برد · {u.stats.gamesPlayed} بازی</p>
          ) : null}
          <div className="mt-4 flex gap-2">
            <button className="btn-primary flex-1" onClick={() => onMessage(u.username)}>
              پیام
            </button>
            <button
              className="flex-1 rounded-2xl border border-white/10"
              onClick={async () => {
                await api("friends", { method: "POST", body: JSON.stringify({ userId: u.id }) });
                onClose();
              }}
            >
              {u.isFriend ? "دوست هستید" : "درخواست دوستی"}
            </button>
          </div>
        </div>
      )}
    </Modal>
  );
}
