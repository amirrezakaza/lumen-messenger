"use client";

import { useEffect, useState } from "react";
import { api, type Me } from "@/lib/client";
import { AuthScreen } from "./AuthScreen";
import { Messenger } from "./Messenger";
import { LumenMark } from "./ui";

export function HomeGate() {
  const [user, setUser] = useState<Me | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let live = true;
    api<{ user: Me }>("auth/me")
      .then((d) => {
        if (live) setUser(d.user);
      })
      .catch(() => {
        if (live) setUser(null);
      })
      .finally(() => {
        if (live) setReady(true);
      });
    return () => {
      live = false;
    };
  }, []);

  if (!ready) {
    return (
      <div className="grid min-h-dvh place-items-center">
        <div className="text-center">
          <LumenMark size={76} />
          <p className="mt-4 text-xs tracking-[0.4em] text-[color:var(--gold)]">LUMEN</p>
        </div>
      </div>
    );
  }

  if (!user) return <AuthScreen onAuthed={setUser} />;
  return <Messenger user={user} setUser={setUser} />;
}
