import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  coins,
  conversationMembers,
  conversations,
  friendships,
  gameStats,
  messages,
  notifications,
  privacySettings,
  users,
} from "@/db/schema";
import { hashPassword } from "@/lib/server";

let seeded = false;
let seeding: Promise<void> | null = null;

export async function ensureSeed() {
  if (seeded) return;
  if (seeding) return seeding;
  seeding = runSeed().finally(() => {
    seeding = null;
  });
  return seeding;
}

async function runSeed() {
  try {
    const existing = await db.select({ id: users.id }).from(users).limit(1);
    if (existing.length) {
      seeded = true;
      return;
    }
  } catch {
    return;
  }

  const passwordHash = await hashPassword("LumenDemo1!");

  const [official] = await db
    .insert(users)
    .values({
      email: "official@lumen.app",
      passwordHash: await hashPassword(crypto.randomUUID() + "Aa1"),
      username: "lumen",
      displayName: "Lumen",
      bio: "پیام‌رسان لومن — نور گفتگو",
      isSystem: true,
      isOnline: true,
    })
    .returning();

  const [luna] = await db
    .insert(users)
    .values({
      email: "luna@lumen.app",
      phone: "+989120000001",
      passwordHash,
      username: "luna",
      displayName: "لونا",
      bio: "طراح محصول · شب‌ها آنلاین‌ام",
    })
    .returning();

  const [kian] = await db
    .insert(users)
    .values({
      email: "kian@lumen.app",
      phone: "+989120000002",
      passwordHash,
      username: "kian",
      displayName: "کیان",
      bio: "عاشق بازی‌های سریع و قهوه سرد",
    })
    .returning();

  const [nika] = await db
    .insert(users)
    .values({
      email: "nika@lumen.app",
      phone: "+989120000003",
      passwordHash,
      username: "nika",
      displayName: "نیکا",
      bio: "موسیقی، سفر، و گفتگوهای نیمه‌شب",
    })
    .returning();

  const people = [official, luna, kian, nika];
  for (const p of people) {
    await db.insert(privacySettings).values({ userId: p.id }).onConflictDoNothing();
    await db.insert(gameStats).values({
      userId: p.id,
      gamesPlayed: p.username === "lumen" ? 0 : 12,
      wins: p.username === "kian" ? 8 : p.username === "luna" ? 5 : p.username === "nika" ? 6 : 0,
      losses: p.username === "kian" ? 3 : 4,
      draws: 1,
      xp: p.username === "kian" ? 420 : p.username === "nika" ? 310 : p.username === "luna" ? 260 : 0,
      level: p.username === "kian" ? 5 : p.username === "nika" ? 4 : p.username === "luna" ? 3 : 1,
    });
    await db.insert(coins).values({
      userId: p.id,
      balance: p.username === "lumen" ? 0 : 180,
    });
  }

  const [channel] = await db
    .insert(conversations)
    .values({
      type: "channel",
      title: "Lumen Official",
      description: "اخبار، نکات و به‌روزرسانی‌های پیام‌رسان لومن",
      createdBy: official.id,
    })
    .returning();

  for (const p of people) {
    await db.insert(conversationMembers).values({
      conversationId: channel.id,
      userId: p.id,
      role: p.id === official.id ? "owner" : "subscriber",
    });
  }

  await db.insert(messages).values([
    {
      conversationId: channel.id,
      senderId: official.id,
      type: "text",
      content:
        "به لومن خوش آمدید — جایی برای گفتگوهای آرام، گروه‌های زنده، کانال‌ها و بازی‌های سریع.",
    },
    {
      conversationId: channel.id,
      senderId: official.id,
      type: "text",
      content:
        "برای شروع، از جستجو دوست پیدا کنید، یک گروه بسازید یا وارد Lumen Games شوید.",
    },
  ]);

  const [dm] = await db
    .insert(conversations)
    .values({ type: "direct", createdBy: luna.id })
    .returning();

  await db.insert(conversationMembers).values([
    { conversationId: dm.id, userId: luna.id, role: "member" },
    { conversationId: dm.id, userId: kian.id, role: "member" },
  ]);

  await db.insert(messages).values([
    {
      conversationId: dm.id,
      senderId: kian.id,
      content: "لونا، ظاهر جدید لومن عالیه. حس یه محصول واقعی رو داره.",
    },
    {
      conversationId: dm.id,
      senderId: luna.id,
      content: "مرسی! امشب تو Lumen Games یه دست دوز بازی کنیم؟",
    },
    {
      conversationId: dm.id,
      senderId: kian.id,
      content: "حتما. بعدش کانال رسمی رو هم چک کن.",
    },
  ]);

  const [group] = await db
    .insert(conversations)
    .values({
      type: "group",
      title: "شب‌های طراحی",
      description: "گپ روزانه تیم",
      createdBy: nika.id,
    })
    .returning();

  await db.insert(conversationMembers).values([
    { conversationId: group.id, userId: nika.id, role: "owner" },
    { conversationId: group.id, userId: luna.id, role: "admin" },
    { conversationId: group.id, userId: kian.id, role: "member" },
  ]);

  await db.insert(messages).values([
    {
      conversationId: group.id,
      senderId: nika.id,
      type: "system",
      content: "گروه «شب‌های طراحی» ساخته شد",
    },
    {
      conversationId: group.id,
      senderId: nika.id,
      content: "سلام‌ها — امروز تم دارک لومن نهایی شد.",
    },
    {
      conversationId: group.id,
      senderId: luna.id,
      content: "انیمیشن ورود پیام‌ها رو هم نرم‌تر کردم.",
    },
  ]);

  await db.insert(friendships).values([
    { requesterId: luna.id, addresseeId: kian.id, status: "accepted" },
    { requesterId: luna.id, addresseeId: nika.id, status: "accepted" },
    { requesterId: kian.id, addresseeId: nika.id, status: "accepted" },
  ]);

  await db.insert(notifications).values({
    userId: luna.id,
    type: "welcome",
    title: "خوش آمدی لونا",
    body: "حساب آزمایشی آماده‌ست. با کیان و نیکا گفتگو کن یا یک بازی شروع کن.",
    data: {},
  });

  seeded = true;
}

export async function subscribeOfficialChannel(userId: string) {
  const [channel] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.title, "Lumen Official"))
    .limit(1);
  if (!channel) return;
  await db
    .insert(conversationMembers)
    .values({
      conversationId: channel.id,
      userId,
      role: "subscriber",
    })
    .onConflictDoNothing();
}
