import {
  boolean,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const conversationTypeEnum = pgEnum("conversation_type", [
  "direct",
  "group",
  "channel",
]);

export const memberRoleEnum = pgEnum("member_role", [
  "owner",
  "admin",
  "moderator",
  "member",
  "subscriber",
]);

export const messageTypeEnum = pgEnum("message_type", [
  "text",
  "image",
  "file",
  "voice",
  "system",
]);

export const friendshipStatusEnum = pgEnum("friendship_status", [
  "pending",
  "accepted",
  "rejected",
  "blocked",
]);

export const matchStatusEnum = pgEnum("match_status", [
  "pending",
  "active",
  "finished",
  "declined",
]);

export const visibilityEnum = pgEnum("visibility", [
  "everyone",
  "friends",
  "nobody",
]);

export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    email: text("email").unique(),
    phone: text("phone").unique(),
    passwordHash: text("password_hash").notNull(),
    username: text("username").notNull().unique(),
    displayName: text("display_name").notNull(),
    avatarUrl: text("avatar_url"),
    bio: text("bio").notNull().default(""),
    lastSeen: timestamp("last_seen", { withTimezone: true }).notNull().defaultNow(),
    isOnline: boolean("is_online").notNull().default(false),
    isSystem: boolean("is_system").notNull().default(false),
    theme: text("theme").notNull().default("aurora"),
    unlockedThemes: text("unlocked_themes").notNull().default("aurora"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("users_username_idx").on(t.username),
    index("users_email_idx").on(t.email),
    index("users_phone_idx").on(t.phone),
  ],
);

export const privacySettings = pgTable("privacy_settings", {
  userId: uuid("user_id")
    .primaryKey()
    .references(() => users.id, { onDelete: "cascade" }),
  lastSeen: visibilityEnum("last_seen").notNull().default("everyone"),
  profilePhoto: visibilityEnum("profile_photo").notNull().default("everyone"),
  onlineStatus: visibilityEnum("online_status").notNull().default("everyone"),
  whoCanMessage: visibilityEnum("who_can_message").notNull().default("everyone"),
  whoCanAddToGroups: visibilityEnum("who_can_add_to_groups")
    .notNull()
    .default("everyone"),
});

export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

export const passwordResets = pgTable("password_resets", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  codeHash: text("code_hash").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  used: boolean("used").notNull().default(false),
});

export const conversations = pgTable(
  "conversations",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    type: conversationTypeEnum("type").notNull(),
    title: text("title"),
    description: text("description"),
    photoUrl: text("photo_url"),
    createdBy: uuid("created_by").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("conversations_type_idx").on(t.type)],
);

export const conversationMembers = pgTable(
  "conversation_members",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    conversationId: uuid("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: memberRoleEnum("role").notNull().default("member"),
    muted: boolean("muted").notNull().default(false),
    pinned: boolean("pinned").notNull().default(false),
    lastReadAt: timestamp("last_read_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    hidden: boolean("hidden").notNull().default(false),
    joinedAt: timestamp("joined_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("conv_member_unique").on(t.conversationId, t.userId),
    index("conv_member_user_idx").on(t.userId),
  ],
);

export const messages = pgTable(
  "messages",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    conversationId: uuid("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    senderId: uuid("sender_id").references(() => users.id, { onDelete: "set null" }),
    content: text("content").notNull().default(""),
    type: messageTypeEnum("type").notNull().default("text"),
    attachment: text("attachment"),
    fileName: text("file_name"),
    mimeType: text("mime_type"),
    replyToId: uuid("reply_to_id"),
    forwardedFrom: text("forwarded_from"),
    editedAt: timestamp("edited_at", { withTimezone: true }),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("messages_conv_created_idx").on(t.conversationId, t.createdAt),
  ],
);

export const messageReactions = pgTable(
  "message_reactions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    messageId: uuid("message_id")
      .notNull()
      .references(() => messages.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    emoji: text("emoji").notNull(),
  },
  (t) => [uniqueIndex("reaction_unique").on(t.messageId, t.userId, t.emoji)],
);

export const friendships = pgTable(
  "friendships",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    requesterId: uuid("requester_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    addresseeId: uuid("addressee_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    status: friendshipStatusEnum("status").notNull().default("pending"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("friendship_pair").on(t.requesterId, t.addresseeId),
    index("friendship_addressee_idx").on(t.addresseeId),
  ],
);

export const gameStats = pgTable("game_stats", {
  userId: uuid("user_id")
    .primaryKey()
    .references(() => users.id, { onDelete: "cascade" }),
  gamesPlayed: integer("games_played").notNull().default(0),
  wins: integer("wins").notNull().default(0),
  losses: integer("losses").notNull().default(0),
  draws: integer("draws").notNull().default(0),
  xp: integer("xp").notNull().default(0),
  level: integer("level").notNull().default(1),
});

export const gameMatches = pgTable(
  "game_matches",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    gameType: text("game_type").notNull(),
    status: matchStatusEnum("status").notNull().default("pending"),
    player1Id: uuid("player1_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    player2Id: uuid("player2_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    turnUserId: uuid("turn_user_id").references(() => users.id, {
      onDelete: "set null",
    }),
    state: jsonb("state")
      .$type<Record<string, unknown>>()
      .notNull()
      .default(sql`'{}'::jsonb`),
    winnerId: text("winner_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("game_matches_p1_idx").on(t.player1Id),
    index("game_matches_p2_idx").on(t.player2Id),
  ],
);

export const coins = pgTable("coins", {
  userId: uuid("user_id")
    .primaryKey()
    .references(() => users.id, { onDelete: "cascade" }),
  balance: integer("balance").notNull().default(100),
});

export const coinTransactions = pgTable(
  "coin_transactions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    amount: integer("amount").notNull(),
    reason: text("reason").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("coin_tx_user_idx").on(t.userId, t.createdAt)],
);

export const notifications = pgTable(
  "notifications",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    type: text("type").notNull(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    data: jsonb("data").$type<Record<string, unknown> | null>(),
    read: boolean("read").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("notifications_user_idx").on(t.userId, t.createdAt)],
);
